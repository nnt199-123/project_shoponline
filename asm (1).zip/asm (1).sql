-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2024 at 03:12 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `asm`
--

-- --------------------------------------------------------

--
-- Table structure for table `binh_luan`
--

CREATE TABLE `binh_luan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_sp` int(11) NOT NULL COMMENT 'Mã sản phẩm',
  `id_user` int(11) NOT NULL COMMENT 'Người bình luận',
  `noi_dung` text NOT NULL COMMENT 'Nội dung bình luận',
  `thoi_diem` datetime NOT NULL COMMENT 'Thời điểm bình luận',
  `an_hien` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 là ẩn 1 là hiện',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `binh_luan`
--

INSERT INTO `binh_luan` (`id`, `id_sp`, `id_user`, `noi_dung`, `thoi_diem`, `an_hien`, `created_at`, `updated_at`) VALUES
(1, 514, 1, 'Sản phẫm này tôi đã từng sử dụng qua, rất hay và mang rất bền. Còn đẹp nữa', '2024-05-31 12:21:11', 0, NULL, NULL),
(2, 514, 1, 'Sản phẩm khá đẹp, mình đã mua nó hơn một năm rồi, xài thấy ổn , không bị nóng, chạy nhanh, không có gặp vấn đề gì về kỹ thuật.', '2024-05-31 12:21:39', 0, NULL, NULL),
(3, 514, 1, 'Sản phẩm này shop còn hàng không, khu vực quận 12. Nếu còn thì phone giúp mình nhé 0918765432', '2024-05-31 12:21:52', 0, NULL, NULL),
(4, 768, 1, 'fffff', '2024-06-02 13:13:49', 0, NULL, NULL),
(5, 768, 5, '123465', '2024-06-02 17:56:22', 0, NULL, NULL),
(6, 768, 5, 'Đơn hàng đẹp', '2024-06-03 07:13:50', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doi_tac`
--

CREATE TABLE `doi_tac` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hinh` varchar(255) DEFAULT NULL,
  `thu_tu` int(11) NOT NULL DEFAULT 0,
  `an_hien` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `don_hang_chi_tiet`
--

CREATE TABLE `don_hang_chi_tiet` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_dh` int(11) NOT NULL COMMENT 'Mã đơn hàng',
  `id_sp` int(11) NOT NULL COMMENT 'Mã sản phẩm',
  `so_luong` int(11) NOT NULL DEFAULT 1 COMMENT 'Số lượng mua',
  `gia` int(11) NOT NULL COMMENT 'Giá mua sản phẩm',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(13, '0001_01_01_000000_create_users_table', 1),
(14, '0001_01_01_000001_create_cache_table', 1),
(15, '0001_01_01_000002_create_jobs_table', 1),
(16, '2024_05_13_150043_cactable', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nha_sx`
--

CREATE TABLE `nha_sx` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ten` varchar(50) NOT NULL,
  `thutu` tinyint(1) NOT NULL DEFAULT 0,
  `anhien` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nha_sx`
--

INSERT INTO `nha_sx` (`id`, `ten`, `thutu`, `anhien`, `created_at`, `updated_at`) VALUES
(1, 'Asus', 1, 1, NULL, NULL),
(2, 'Acer', 2, 1, NULL, NULL),
(3, 'Lenovo', 4, 1, NULL, NULL),
(4, 'MSI', 5, 1, NULL, NULL),
(5, 'HP', 3, 1, NULL, NULL),
(6, 'Dell', 8, 1, NULL, NULL),
(7, 'Apple', 9, 1, NULL, NULL),
(8, 'Surface', 10, 1, NULL, NULL),
(9, 'Masstel', 7, 0, NULL, NULL),
(10, 'LG', 6, 1, NULL, NULL),
(11, 'Iphone', 0, 1, '2024-06-06 16:40:03', '2024-06-06 16:40:03'),
(12, 'Sam Sum', 0, 1, '2024-06-06 16:40:51', '2024-06-06 16:40:51');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `san_pham`
--

CREATE TABLE `san_pham` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ten` varchar(50) NOT NULL,
  `idnhasx` int(11) NOT NULL,
  `gia` int(11) NOT NULL DEFAULT 0,
  `giakm` int(11) NOT NULL DEFAULT 0,
  `hing` varchar(255) DEFAULT NULL,
  `ngay` date NOT NULL DEFAULT current_timestamp(),
  `xem` int(11) NOT NULL DEFAULT 0,
  `hot` tinyint(1) NOT NULL DEFAULT 0,
  `anhien` tinyint(1) NOT NULL DEFAULT 1,
  `tinhchat` tinyint(1) NOT NULL DEFAULT 0,
  `mausac` varchar(50) DEFAULT NULL,
  `cannang` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `san_pham`
--

INSERT INTO `san_pham` (`id`, `ten`, `idnhasx`, `gia`, `giakm`, `hing`, `ngay`, `xem`, `hot`, `anhien`, `tinhchat`, `mausac`, `cannang`, `created_at`, `updated_at`) VALUES
(1, 'Vàng', 7, 27150698, 12132254, 'product-1.jpg', '2024-05-31', 953, 1, 0, 3, 'cam', '1 kg', NULL, NULL),
(2, 'Iphone', 10, 28394717, 12976872, 'product-5.jpg', '2024-05-31', 365, 1, 1, 0, 'den', '2 kg', NULL, NULL),
(3, 'Asus', 10, 21793577, 12154921, 'product-4.jpg', '2024-05-31', 319, 1, 1, 3, 'trang', '3 kg', NULL, NULL),
(4, 'Camera', 10, 28650066, 12397338, 'product-8.jpg', '2024-05-31', 687, 1, 1, 1, 'den', '3 kg', NULL, NULL),
(5, 'Camera', 1, 27850241, 12673597, 'product-8.jpg', '2024-05-31', 755, 1, 0, 3, 'cam', '3 kg', NULL, NULL),
(6, 'Đầm phụ nữ', 5, 26709820, 13369417, 'product-8.jpg', '2024-05-31', 1116, 0, 0, 3, 'cam', '1 kg', NULL, NULL),
(7, 'Vàng', 10, 29557633, 10576419, 'product-3.jpg', '2024-05-31', 954, 0, 1, 4, 'trang', '3 kg', NULL, NULL),
(8, 'Bạc', 4, 21457054, 11535430, 'cat-2.jpg', '2024-05-31', 786, 0, 0, 2, 'trang', '2 kg', NULL, NULL),
(9, 'Vàng', 3, 29101281, 10195478, 'cat-3.jpg', '2024-05-31', 916, 0, 1, 0, 'trang', '1 kg', NULL, NULL),
(10, 'Banana', 8, 23533450, 11051114, 'product-4.jpg', '2024-05-31', 992, 1, 1, 3, 'cam', '1 kg', NULL, NULL),
(11, 'Banana', 6, 26355981, 11670440, 'cat-2.jpg', '2024-05-31', 632, 1, 0, 1, 'cam', '3 kg', NULL, NULL),
(12, 'Vàng', 5, 26735261, 13576622, 'product-3.jpg', '2024-05-31', 1823, 0, 1, 1, 'cam', '2 kg', NULL, NULL),
(13, 'Mx97', 3, 20408578, 14060795, 'product-5.jpg', '2024-05-31', 1527, 1, 0, 4, 'vang', '2 kg', NULL, NULL),
(14, 'Asus', 8, 20916066, 11929407, 'product-8.jpg', '2024-05-31', 1448, 0, 1, 1, 'vang', '3 kg', NULL, NULL),
(15, 'Asus', 4, 23270937, 10300261, 'cat-4.jpg', '2024-05-31', 794, 1, 1, 4, 'den', '3 kg', NULL, NULL),
(16, 'Bạc', 10, 24433597, 12928606, 'product-8.jpg', '2024-05-31', 1111, 0, 1, 0, 'den', '2 kg', NULL, NULL),
(17, 'Nước hoa nữ', 5, 29441300, 12002745, 'product-1.jpg', '2024-05-31', 1001, 1, 1, 1, 'den', '2 kg', NULL, NULL),
(18, 'Mx97', 1, 29746196, 12805431, 'product-1.jpg', '2024-05-31', 1340, 0, 1, 1, 'vang', '2 kg', NULL, NULL),
(19, 'Mx97', 7, 28843947, 12426520, 'product-6.jpg', '2024-05-31', 939, 0, 1, 3, 'cam', '1 kg', NULL, NULL),
(20, 'G12', 5, 25198977, 10486595, 'product-5.jpg', '2024-05-31', 1931, 0, 1, 4, 'cam', '2 kg', NULL, NULL),
(21, 'Iphone', 8, 26649535, 12100363, 'product-3.jpg', '2024-05-31', 673, 1, 0, 1, 'cam', '2 kg', NULL, NULL),
(22, 'Đầm phụ nữ', 9, 26627253, 12978028, 'product-2.jpg', '2024-05-31', 976, 1, 0, 1, 'trang', '1 kg', NULL, NULL),
(23, 'Nước hoa nữ', 3, 20345950, 13011677, 'product-3.jpg', '2024-05-31', 695, 0, 1, 2, 'den', '3 kg', NULL, NULL),
(24, 'Camera', 2, 22424089, 13887404, 'cat-1.jpg', '2024-05-31', 1865, 1, 1, 4, 'cam', '3 kg', NULL, NULL),
(25, 'Vàng', 3, 26868504, 14498380, 'product-2.jpg', '2024-05-31', 925, 0, 1, 1, 'cam', '2 kg', NULL, NULL),
(26, 'Banana', 1, 24220738, 13574151, 'product-4.jpg', '2024-05-31', 1284, 0, 1, 4, 'cam', '2 kg', NULL, NULL),
(27, 'Đầm phụ nữ', 9, 22348786, 11129266, 'cat-2.jpg', '2024-05-31', 1308, 0, 0, 1, 'vang', '2 kg', NULL, NULL),
(28, 'Iphone', 7, 25445192, 14727675, 'cat-1.jpg', '2024-05-31', 1241, 1, 0, 2, 'den', '3 kg', NULL, NULL),
(29, 'Banana', 10, 23999946, 14347798, 'product-1.jpg', '2024-05-31', 1849, 1, 1, 2, 'cam', '3 kg', NULL, NULL),
(30, 'Mx97', 6, 26452085, 11114977, 'product-5.jpg', '2024-05-31', 1408, 1, 1, 3, 'trang', '1 kg', NULL, NULL),
(31, 'Kim cương', 3, 20071540, 12726384, 'product-7.jpg', '2024-05-31', 1519, 1, 1, 4, 'den', '3 kg', NULL, NULL),
(32, 'Camera', 5, 29155548, 11284474, 'product-8.jpg', '2024-05-31', 981, 1, 0, 2, 'cam', '3 kg', NULL, NULL),
(33, 'Đầm phụ nữ', 7, 26043113, 12381393, 'product-4.jpg', '2024-05-31', 634, 0, 1, 1, 'cam', '1 kg', NULL, NULL),
(34, 'Lenovo', 2, 26341824, 12469820, 'product-2.jpg', '2024-05-31', 1517, 1, 1, 2, 'cam', '3 kg', NULL, NULL),
(35, 'Đầm phụ nữ', 2, 26419852, 14278366, 'cat-4.jpg', '2024-05-31', 453, 1, 1, 2, 'vang', '1 kg', NULL, NULL),
(36, 'G12', 5, 20310873, 11465700, 'product-1.jpg', '2024-05-31', 1570, 1, 0, 2, 'trang', '1 kg', NULL, NULL),
(37, 'Banana', 4, 20315751, 13739451, 'product-3.jpg', '2024-05-31', 1865, 0, 1, 0, 'cam', '2 kg', NULL, NULL),
(38, 'G12', 8, 21467149, 10395365, 'product-8.jpg', '2024-05-31', 527, 0, 1, 2, 'cam', '3 kg', NULL, NULL),
(39, 'Lenovo', 9, 24641576, 12660083, 'product-4.jpg', '2024-05-31', 1009, 0, 0, 0, 'trang', '3 kg', NULL, NULL),
(40, 'Banana', 7, 26347058, 14915911, 'product-3.jpg', '2024-05-31', 210, 1, 0, 3, 'den', '3 kg', NULL, NULL),
(41, 'Asus', 6, 20524832, 10758746, 'product-7.jpg', '2024-05-31', 137, 0, 0, 3, 'vang', '2 kg', NULL, NULL),
(42, 'Bạc', 7, 27381580, 11489744, 'product-6.jpg', '2024-05-31', 650, 0, 1, 2, 'den', '1 kg', NULL, NULL),
(43, 'Mx97', 10, 24207517, 13818984, 'cat-3.jpg', '2024-05-31', 331, 0, 1, 4, 'den', '2 kg', NULL, NULL),
(44, 'Đầm phụ nữ', 3, 28576750, 14523832, 'product-2.jpg', '2024-05-31', 413, 1, 0, 0, 'den', '1 kg', NULL, NULL),
(45, 'Apple', 1, 25081995, 10592731, 'cat-4.jpg', '2024-05-31', 120, 1, 0, 2, 'den', '3 kg', NULL, NULL),
(46, 'Lenovo', 9, 28502032, 14601283, 'product-9.jpg', '2024-05-31', 272, 0, 1, 2, 'den', '1 kg', NULL, NULL),
(47, 'Vàng', 8, 22171942, 10124652, 'product-6.jpg', '2024-05-31', 1148, 0, 0, 0, 'vang', '2 kg', NULL, NULL),
(48, 'Lenovo', 10, 22152160, 13135059, 'product-9.jpg', '2024-05-31', 1744, 0, 1, 1, 'trang', '1 kg', NULL, NULL),
(49, 'G12', 3, 23811494, 10967649, 'cat-1.jpg', '2024-05-31', 1236, 1, 0, 0, 'vang', '3 kg', NULL, NULL),
(50, 'Nước hoa nữ', 7, 28551094, 14156910, 'product-2.jpg', '2024-05-31', 1327, 0, 0, 3, 'den', '2 kg', NULL, NULL),
(51, 'Iphone', 1, 24630003, 11130639, 'product-5.jpg', '2024-05-31', 1787, 0, 0, 4, 'vang', '3 kg', NULL, NULL),
(52, 'Đầm phụ nữ', 6, 29133083, 12716697, 'cat-3.jpg', '2024-05-31', 1706, 1, 1, 0, 'trang', '3 kg', NULL, NULL),
(53, 'Bạc', 3, 22503731, 12462890, 'product-9.jpg', '2024-05-31', 1621, 0, 1, 4, 'cam', '2 kg', NULL, NULL),
(54, 'Đầm phụ nữ', 1, 28764829, 11693868, 'product-2.jpg', '2024-05-31', 1383, 1, 1, 4, 'den', '2 kg', NULL, NULL),
(55, 'Bạc', 10, 25092733, 14067262, 'cat-1.jpg', '2024-05-31', 1890, 1, 0, 2, 'cam', '2 kg', NULL, NULL),
(56, 'Đầm phụ nữ', 1, 28715222, 13968546, 'product-3.jpg', '2024-05-31', 1816, 0, 1, 4, 'trang', '2 kg', NULL, NULL),
(57, 'Nước hoa nam', 6, 24240925, 12860420, 'product-9.jpg', '2024-05-31', 1747, 1, 0, 0, 'vang', '1 kg', NULL, NULL),
(58, 'Nước hoa nam', 10, 23343899, 12786333, 'cat-3.jpg', '2024-05-31', 1329, 0, 0, 3, 'cam', '3 kg', NULL, NULL),
(59, 'Iphone', 3, 20954462, 12189783, 'product-4.jpg', '2024-05-31', 705, 0, 1, 4, 'den', '2 kg', NULL, NULL),
(60, 'G12', 5, 24864882, 12066035, 'product-1.jpg', '2024-05-31', 745, 0, 0, 0, 'cam', '3 kg', NULL, NULL),
(61, 'Nước hoa nữ', 5, 21074548, 10588307, 'product-1.jpg', '2024-05-31', 836, 1, 0, 3, 'den', '3 kg', NULL, NULL),
(62, 'Nước hoa nam', 7, 29611074, 13448057, 'product-7.jpg', '2024-05-31', 308, 0, 0, 3, 'den', '1 kg', NULL, NULL),
(63, 'Apple', 6, 20690203, 13625074, 'product-6.jpg', '2024-05-31', 1567, 1, 0, 4, 'den', '1 kg', NULL, NULL),
(64, 'Nước hoa nữ', 9, 22398169, 11167957, 'product-7.jpg', '2024-05-31', 668, 1, 0, 1, 'trang', '3 kg', NULL, NULL),
(65, 'G12', 4, 20023257, 14545266, 'product-8.jpg', '2024-05-31', 1064, 0, 1, 3, 'trang', '3 kg', NULL, NULL),
(66, 'Vàng', 6, 25299599, 12255677, 'product-1.jpg', '2024-05-31', 637, 0, 0, 1, 'vang', '2 kg', NULL, NULL),
(67, 'G12', 3, 22237612, 11817364, 'cat-2.jpg', '2024-05-31', 1819, 1, 1, 4, 'cam', '2 kg', NULL, NULL),
(68, 'Iphone', 3, 24789282, 10015467, 'cat-2.jpg', '2024-05-31', 1710, 1, 1, 0, 'trang', '3 kg', NULL, NULL),
(69, 'G12', 9, 26021469, 14396303, 'cat-4.jpg', '2024-05-31', 127, 1, 0, 3, 'trang', '3 kg', NULL, NULL),
(70, 'Nước hoa nam', 7, 20292644, 12596655, 'product-5.jpg', '2024-05-31', 490, 0, 0, 0, 'cam', '1 kg', NULL, NULL),
(71, 'Lenovo', 2, 24502971, 14834015, 'cat-4.jpg', '2024-05-31', 1111, 0, 0, 1, 'den', '1 kg', NULL, NULL),
(72, 'Iphone', 9, 20908558, 11148128, 'product-6.jpg', '2024-05-31', 1784, 0, 0, 0, 'trang', '2 kg', NULL, NULL),
(73, 'Mx97', 7, 25394524, 10863972, 'product-5.jpg', '2024-05-31', 309, 1, 0, 2, 'cam', '2 kg', NULL, NULL),
(74, 'Nước hoa nữ', 9, 29834705, 12578521, 'cat-4.jpg', '2024-05-31', 909, 1, 0, 3, 'trang', '1 kg', NULL, NULL),
(75, 'Asus', 3, 24511693, 13568848, 'product-1.jpg', '2024-05-31', 1625, 1, 1, 3, 'cam', '1 kg', NULL, NULL),
(76, 'Đầm phụ nữ', 2, 25539530, 12663490, 'cat-3.jpg', '2024-05-31', 1564, 1, 0, 0, 'vang', '3 kg', NULL, NULL),
(77, 'Mx97', 5, 22192906, 14583095, 'product-7.jpg', '2024-05-31', 1465, 1, 0, 4, 'cam', '2 kg', NULL, NULL),
(78, 'Vàng', 5, 25811077, 12142812, 'product-2.jpg', '2024-05-31', 21, 1, 0, 3, 'vang', '2 kg', NULL, NULL),
(79, 'Đầm phụ nữ', 7, 20148875, 11811583, 'product-3.jpg', '2024-05-31', 1863, 0, 1, 1, 'trang', '1 kg', NULL, NULL),
(80, 'Camera', 7, 29765178, 10891069, 'product-5.jpg', '2024-05-31', 1402, 1, 1, 3, 'vang', '1 kg', NULL, NULL),
(81, 'Nước hoa nữ', 1, 22171574, 11064678, 'product-9.jpg', '2024-05-31', 1072, 1, 1, 0, 'cam', '2 kg', NULL, NULL),
(82, 'Kim cương', 5, 25505794, 10054061, 'cat-4.jpg', '2024-05-31', 1903, 1, 0, 0, 'cam', '2 kg', NULL, NULL),
(83, 'Iphone', 7, 28397773, 13615857, 'product-6.jpg', '2024-05-31', 369, 1, 0, 0, 'vang', '3 kg', NULL, NULL),
(84, 'Bạc', 8, 22001055, 14315359, 'product-9.jpg', '2024-05-31', 1127, 0, 1, 2, 'cam', '1 kg', NULL, NULL),
(85, 'G12', 9, 20222795, 10915522, 'product-6.jpg', '2024-05-31', 1159, 0, 1, 0, 'cam', '1 kg', NULL, NULL),
(86, 'Bạc', 4, 22439864, 13057129, 'product-5.jpg', '2024-05-31', 1968, 1, 0, 0, 'cam', '1 kg', NULL, NULL),
(87, 'Lenovo', 1, 21067245, 13227813, 'cat-1.jpg', '2024-05-31', 1843, 1, 1, 3, 'vang', '2 kg', NULL, NULL),
(88, 'Nước hoa nữ', 9, 21734613, 12445459, 'product-1.jpg', '2024-05-31', 1484, 0, 0, 4, 'cam', '1 kg', NULL, NULL),
(89, 'Iphone', 9, 22403127, 13918218, 'product-1.jpg', '2024-05-31', 1093, 0, 0, 3, 'den', '1 kg', NULL, NULL),
(90, 'Mx97', 3, 29369225, 12110137, 'product-6.jpg', '2024-05-31', 316, 0, 0, 0, 'trang', '1 kg', NULL, NULL),
(91, 'Asus', 9, 29605534, 13278932, 'cat-3.jpg', '2024-05-31', 471, 1, 1, 3, 'cam', '3 kg', NULL, NULL),
(92, 'G12', 10, 24683638, 10445086, 'product-5.jpg', '2024-05-31', 1146, 0, 1, 3, 'cam', '3 kg', NULL, NULL),
(93, 'Iphone', 2, 29993933, 11182121, 'product-9.jpg', '2024-05-31', 1303, 0, 1, 1, 'vang', '1 kg', NULL, NULL),
(94, 'Bạc', 8, 22978666, 14065344, 'cat-4.jpg', '2024-05-31', 1271, 1, 1, 0, 'cam', '3 kg', NULL, NULL),
(95, 'Camera', 10, 28331880, 12616219, 'product-3.jpg', '2024-05-31', 1774, 0, 0, 2, 'den', '3 kg', NULL, NULL),
(96, 'Kim cương', 2, 28998016, 10710704, 'cat-1.jpg', '2024-05-31', 475, 0, 0, 1, 'cam', '3 kg', NULL, NULL),
(97, 'Lenovo', 8, 28997048, 11685002, 'product-7.jpg', '2024-05-31', 1987, 1, 1, 1, 'cam', '3 kg', NULL, NULL),
(98, 'Mx97', 4, 20646174, 10241346, 'product-7.jpg', '2024-05-31', 57, 0, 0, 0, 'cam', '2 kg', NULL, NULL),
(99, 'Mx97', 5, 20798631, 13985269, 'product-9.jpg', '2024-05-31', 486, 0, 1, 1, 'cam', '1 kg', NULL, NULL),
(100, 'Lenovo', 4, 24981407, 14191642, 'product-6.jpg', '2024-05-31', 446, 0, 0, 2, 'vang', '2 kg', NULL, NULL),
(101, 'Kim cương', 7, 27093366, 11435208, 'cat-2.jpg', '2024-05-31', 1250, 1, 1, 1, 'trang', '1 kg', NULL, NULL),
(102, 'Kim cương', 3, 20165318, 10469373, 'product-6.jpg', '2024-05-31', 639, 0, 1, 4, 'cam', '2 kg', NULL, NULL),
(103, 'Nước hoa nam', 10, 25381732, 14681154, 'product-4.jpg', '2024-05-31', 1256, 0, 1, 0, 'den', '2 kg', NULL, NULL),
(104, 'Iphone', 7, 27657370, 13167379, 'product-2.jpg', '2024-05-31', 609, 0, 0, 3, 'den', '3 kg', NULL, NULL),
(105, 'Mx97', 2, 26566381, 13941844, 'product-9.jpg', '2024-05-31', 1658, 1, 0, 1, 'cam', '1 kg', NULL, NULL),
(106, 'Nước hoa nam', 6, 25583833, 10695695, 'product-6.jpg', '2024-05-31', 1927, 1, 1, 3, 'vang', '3 kg', NULL, NULL),
(107, 'Kim cương', 6, 21542304, 13159960, 'product-4.jpg', '2024-05-31', 168, 0, 0, 1, 'vang', '2 kg', NULL, NULL),
(108, 'G12', 1, 25825029, 10292662, 'product-7.jpg', '2024-05-31', 771, 0, 1, 2, 'den', '2 kg', NULL, NULL),
(109, 'Kim cương', 10, 21032596, 12896200, 'cat-3.jpg', '2024-05-31', 758, 1, 0, 4, 'trang', '1 kg', NULL, NULL),
(110, 'Camera', 9, 20678013, 12030598, 'cat-2.jpg', '2024-05-31', 1570, 0, 0, 1, 'vang', '1 kg', NULL, NULL),
(111, 'Asus', 9, 22648135, 12674406, 'cat-3.jpg', '2024-05-31', 1437, 0, 0, 1, 'vang', '2 kg', NULL, NULL),
(112, 'Iphone', 2, 26874379, 14147206, 'product-5.jpg', '2024-05-31', 856, 1, 0, 3, 'den', '2 kg', NULL, NULL),
(113, 'Bạc', 7, 25096337, 10245344, 'product-5.jpg', '2024-05-31', 1479, 1, 1, 3, 'den', '1 kg', NULL, NULL),
(114, 'Vàng', 4, 23979245, 13102243, 'cat-1.jpg', '2024-05-31', 568, 1, 1, 4, 'cam', '1 kg', NULL, NULL),
(115, 'G12', 7, 23333251, 14955473, 'product-2.jpg', '2024-05-31', 529, 0, 0, 0, 'den', '2 kg', NULL, NULL),
(116, 'Camera', 9, 20615990, 12507789, 'cat-4.jpg', '2024-05-31', 755, 1, 0, 4, 'cam', '2 kg', NULL, NULL),
(117, 'G12', 8, 24192741, 10081851, 'cat-3.jpg', '2024-05-31', 249, 0, 1, 2, 'vang', '1 kg', NULL, NULL),
(118, 'Mx97', 3, 24425329, 11004812, 'cat-3.jpg', '2024-05-31', 1583, 1, 0, 4, 'den', '2 kg', NULL, NULL),
(119, 'Vàng', 3, 28911037, 11167208, 'cat-4.jpg', '2024-05-31', 1800, 1, 0, 1, 'trang', '1 kg', NULL, NULL),
(120, 'Nước hoa nam', 9, 23519780, 10862250, 'product-7.jpg', '2024-05-31', 1686, 0, 1, 2, 'cam', '3 kg', NULL, NULL),
(121, 'Đầm phụ nữ', 10, 25869793, 10382553, 'cat-3.jpg', '2024-05-31', 579, 1, 1, 3, 'den', '3 kg', NULL, NULL),
(122, 'Iphone', 8, 28294223, 10738554, 'cat-3.jpg', '2024-05-31', 1976, 1, 1, 2, 'trang', '2 kg', NULL, NULL),
(123, 'Đầm phụ nữ', 8, 27260780, 14989710, 'cat-1.jpg', '2024-05-31', 36, 0, 1, 1, 'cam', '3 kg', NULL, NULL),
(124, 'Nước hoa nữ', 5, 27276578, 13035374, 'product-3.jpg', '2024-05-31', 1162, 0, 0, 2, 'trang', '1 kg', NULL, NULL),
(125, 'Iphone', 10, 21347643, 13784692, 'product-3.jpg', '2024-05-31', 483, 1, 0, 0, 'den', '3 kg', NULL, NULL),
(126, 'Lenovo', 1, 25334028, 12995660, 'product-7.jpg', '2024-05-31', 916, 1, 0, 4, 'vang', '3 kg', NULL, NULL),
(127, 'Camera', 6, 25089505, 10530674, 'product-4.jpg', '2024-05-31', 1377, 1, 1, 3, 'trang', '2 kg', NULL, NULL),
(128, 'Banana', 7, 24221531, 11198588, 'cat-3.jpg', '2024-05-31', 1380, 0, 0, 2, 'cam', '2 kg', NULL, NULL),
(129, 'Vàng', 1, 21173978, 11403277, 'product-7.jpg', '2024-05-31', 1168, 0, 0, 1, 'den', '3 kg', NULL, NULL),
(130, 'Đầm phụ nữ', 1, 23018766, 13014423, 'product-2.jpg', '2024-05-31', 1246, 1, 0, 1, 'vang', '3 kg', NULL, NULL),
(131, 'Banana', 6, 28888955, 12515366, 'product-1.jpg', '2024-05-31', 1425, 0, 0, 1, 'vang', '1 kg', NULL, NULL),
(132, 'Nước hoa nữ', 5, 26411279, 13720646, 'cat-2.jpg', '2024-05-31', 49, 1, 0, 3, 'den', '3 kg', NULL, NULL),
(133, 'Nước hoa nữ', 5, 27192971, 10588273, 'product-3.jpg', '2024-05-31', 1267, 1, 0, 4, 'trang', '3 kg', NULL, NULL),
(134, 'Nước hoa nam', 3, 25063888, 10599487, 'cat-4.jpg', '2024-05-31', 1509, 1, 0, 1, 'den', '1 kg', NULL, NULL),
(135, 'Lenovo', 6, 23850565, 13414068, 'product-2.jpg', '2024-05-31', 610, 1, 0, 1, 'cam', '1 kg', NULL, NULL),
(136, 'Lenovo', 8, 28807868, 12308440, 'product-9.jpg', '2024-05-31', 1805, 0, 1, 4, 'den', '1 kg', NULL, NULL),
(137, 'Asus', 7, 21251829, 11108668, 'cat-2.jpg', '2024-05-31', 1395, 0, 1, 1, 'cam', '2 kg', NULL, NULL),
(138, 'Vàng', 5, 21828104, 14814108, 'cat-3.jpg', '2024-05-31', 147, 0, 0, 4, 'den', '1 kg', NULL, NULL),
(139, 'Asus', 4, 27718972, 11533425, 'cat-2.jpg', '2024-05-31', 1103, 1, 1, 4, 'den', '3 kg', NULL, NULL),
(140, 'Lenovo', 7, 24986342, 13784579, 'cat-3.jpg', '2024-05-31', 1691, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(141, 'Asus', 3, 27298898, 12182430, 'cat-3.jpg', '2024-05-31', 158, 1, 1, 4, 'den', '3 kg', NULL, NULL),
(142, 'Bạc', 3, 27161072, 11628722, 'product-7.jpg', '2024-05-31', 109, 1, 1, 3, 'den', '3 kg', NULL, NULL),
(143, 'Lenovo', 8, 27319266, 14413569, 'product-1.jpg', '2024-05-31', 1655, 0, 1, 1, 'trang', '2 kg', NULL, NULL),
(144, 'Lenovo', 6, 29973371, 14195453, 'product-9.jpg', '2024-05-31', 85, 1, 1, 3, 'vang', '2 kg', NULL, NULL),
(145, 'Nước hoa nữ', 4, 26194804, 14558193, 'product-2.jpg', '2024-05-31', 733, 1, 1, 1, 'den', '3 kg', NULL, NULL),
(146, 'Bạc', 10, 23955261, 13114039, 'cat-1.jpg', '2024-05-31', 380, 1, 0, 2, 'den', '2 kg', NULL, NULL),
(147, 'Đầm phụ nữ', 9, 27674682, 13139048, 'product-6.jpg', '2024-05-31', 1652, 0, 1, 3, 'vang', '2 kg', NULL, NULL),
(148, 'Lenovo', 2, 20163986, 13433757, 'cat-2.jpg', '2024-05-31', 469, 1, 0, 0, 'trang', '2 kg', NULL, NULL),
(149, 'Mx97', 5, 28076125, 14765277, 'product-9.jpg', '2024-05-31', 79, 1, 0, 3, 'cam', '2 kg', NULL, NULL),
(150, 'Lenovo', 3, 23364392, 10656529, 'cat-1.jpg', '2024-05-31', 450, 0, 1, 4, 'trang', '1 kg', NULL, NULL),
(151, 'Mx97', 1, 27385373, 11685363, 'product-3.jpg', '2024-05-31', 1457, 1, 0, 0, 'den', '3 kg', NULL, NULL),
(152, 'Vàng', 2, 26844742, 11015783, 'cat-3.jpg', '2024-05-31', 1854, 0, 1, 3, 'trang', '2 kg', NULL, NULL),
(153, 'Đầm phụ nữ', 10, 23403162, 12500421, 'cat-2.jpg', '2024-05-31', 139, 0, 0, 0, 'trang', '1 kg', NULL, NULL),
(154, 'Mx97', 7, 29374491, 11987408, 'cat-1.jpg', '2024-05-31', 1970, 1, 0, 0, 'vang', '2 kg', NULL, NULL),
(155, 'Bạc', 4, 27373796, 13428036, 'product-6.jpg', '2024-05-31', 1506, 1, 0, 3, 'den', '2 kg', NULL, NULL),
(156, 'Nước hoa nam', 10, 29382878, 11512022, 'product-9.jpg', '2024-05-31', 1312, 0, 1, 0, 'den', '2 kg', NULL, NULL),
(157, 'Iphone', 7, 20621326, 14685475, 'cat-1.jpg', '2024-05-31', 1451, 0, 0, 3, 'cam', '1 kg', NULL, NULL),
(158, 'Camera', 3, 20686908, 11059864, 'product-7.jpg', '2024-05-31', 1955, 0, 1, 2, 'trang', '1 kg', NULL, NULL),
(159, 'Kim cương', 5, 29240873, 14218531, 'cat-2.jpg', '2024-05-31', 932, 0, 0, 3, 'vang', '1 kg', NULL, NULL),
(160, 'Đầm phụ nữ', 3, 24805978, 13438420, 'cat-4.jpg', '2024-05-31', 586, 0, 0, 4, 'den', '1 kg', NULL, NULL),
(161, 'G12', 10, 28161967, 14663662, 'cat-3.jpg', '2024-05-31', 1021, 0, 0, 0, 'den', '3 kg', NULL, NULL),
(162, 'Bạc', 1, 21714603, 13449739, 'cat-3.jpg', '2024-05-31', 1529, 0, 0, 2, 'vang', '1 kg', NULL, NULL),
(163, 'Kim cương', 9, 26200097, 14249781, 'product-5.jpg', '2024-05-31', 1017, 1, 1, 3, 'cam', '2 kg', NULL, NULL),
(164, 'Iphone', 4, 27942590, 14897232, 'product-4.jpg', '2024-05-31', 1552, 1, 0, 1, 'vang', '2 kg', NULL, NULL),
(165, 'Camera', 7, 21995020, 13566793, 'cat-1.jpg', '2024-05-31', 1665, 1, 0, 2, 'den', '2 kg', NULL, NULL),
(166, 'Camera', 6, 24373280, 11903070, 'product-8.jpg', '2024-05-31', 1891, 1, 1, 0, 'den', '1 kg', NULL, NULL),
(167, 'G12', 9, 24394707, 11499043, 'product-4.jpg', '2024-05-31', 1698, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(168, 'Mx97', 3, 20206645, 13178102, 'product-5.jpg', '2024-05-31', 1455, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(169, 'Đầm phụ nữ', 5, 29704091, 10735656, 'product-6.jpg', '2024-05-31', 748, 1, 0, 1, 'den', '3 kg', NULL, NULL),
(170, 'Lenovo', 3, 22560591, 12344330, 'cat-1.jpg', '2024-05-31', 1466, 0, 0, 1, 'cam', '3 kg', NULL, NULL),
(171, 'Bạc', 2, 25754490, 14781434, 'product-9.jpg', '2024-05-31', 1167, 1, 0, 0, 'cam', '1 kg', NULL, NULL),
(172, 'Iphone', 5, 25903305, 10024548, 'cat-2.jpg', '2024-05-31', 1778, 0, 0, 4, 'vang', '1 kg', NULL, NULL),
(173, 'Vàng', 7, 27056716, 12195799, 'product-9.jpg', '2024-05-31', 1572, 0, 1, 4, 'cam', '1 kg', NULL, NULL),
(174, 'Iphone', 5, 22835662, 10379938, 'product-7.jpg', '2024-05-31', 1610, 0, 0, 1, 'vang', '1 kg', NULL, NULL),
(175, 'Vàng', 1, 22639987, 10766802, 'product-4.jpg', '2024-05-31', 329, 1, 1, 4, 'den', '2 kg', NULL, NULL),
(176, 'G12', 9, 26565206, 14322107, 'product-4.jpg', '2024-05-31', 1100, 1, 0, 0, 'cam', '3 kg', NULL, NULL),
(177, 'Camera', 1, 20030813, 13570036, 'product-2.jpg', '2024-05-31', 48, 1, 0, 3, 'trang', '3 kg', NULL, NULL),
(178, 'Camera', 6, 27586823, 13437933, 'product-7.jpg', '2024-05-31', 21, 1, 0, 0, 'cam', '2 kg', NULL, NULL),
(179, 'Mx97', 1, 25052038, 14189593, 'cat-4.jpg', '2024-05-31', 1855, 1, 0, 4, 'den', '2 kg', NULL, NULL),
(180, 'Mx97', 2, 29013115, 13853172, 'product-4.jpg', '2024-05-31', 1864, 0, 1, 1, 'cam', '2 kg', NULL, NULL),
(181, 'Asus', 7, 21979325, 14181777, 'cat-1.jpg', '2024-05-31', 1337, 0, 0, 3, 'trang', '2 kg', NULL, NULL),
(182, 'G12', 6, 24052826, 11981862, 'cat-2.jpg', '2024-05-31', 222, 1, 1, 2, 'den', '2 kg', NULL, NULL),
(183, 'Đầm phụ nữ', 6, 26462119, 10526353, 'cat-2.jpg', '2024-05-31', 1509, 0, 1, 3, 'vang', '1 kg', NULL, NULL),
(184, 'Asus', 3, 29501027, 12566110, 'product-5.jpg', '2024-05-31', 1930, 0, 0, 3, 'den', '2 kg', NULL, NULL),
(185, 'Nước hoa nữ', 10, 21873404, 12253338, 'product-2.jpg', '2024-05-31', 1808, 1, 0, 3, 'den', '1 kg', NULL, NULL),
(186, 'Bạc', 6, 29204841, 13939514, 'product-8.jpg', '2024-05-31', 6, 1, 1, 1, 'cam', '1 kg', NULL, NULL),
(187, 'Apple', 3, 21485712, 14162318, 'product-9.jpg', '2024-05-31', 498, 0, 0, 1, 'vang', '3 kg', NULL, NULL),
(188, 'Đầm phụ nữ', 6, 29851022, 14168492, 'product-4.jpg', '2024-05-31', 952, 0, 1, 1, 'vang', '1 kg', NULL, NULL),
(189, 'Camera', 6, 29605818, 12216850, 'cat-3.jpg', '2024-05-31', 766, 0, 0, 3, 'cam', '1 kg', NULL, NULL),
(190, 'Mx97', 6, 29313793, 12802057, 'cat-3.jpg', '2024-05-31', 785, 1, 1, 1, 'trang', '1 kg', NULL, NULL),
(191, 'Mx97', 7, 29468589, 12138515, 'product-3.jpg', '2024-05-31', 394, 1, 1, 4, 'vang', '3 kg', NULL, NULL),
(192, 'Vàng', 9, 21123458, 12071076, 'cat-4.jpg', '2024-05-31', 45, 0, 0, 1, 'cam', '1 kg', NULL, NULL),
(193, 'Asus', 6, 24787843, 10645728, 'cat-4.jpg', '2024-05-31', 252, 1, 0, 0, 'den', '1 kg', NULL, NULL),
(194, 'Apple', 4, 23728123, 13148122, 'product-6.jpg', '2024-05-31', 907, 1, 1, 3, 'cam', '2 kg', NULL, NULL),
(195, 'Asus', 3, 21057844, 12460620, 'product-2.jpg', '2024-05-31', 1786, 0, 1, 1, 'cam', '1 kg', NULL, NULL),
(196, 'Nước hoa nữ', 2, 23043220, 12268493, 'product-2.jpg', '2024-05-31', 1512, 1, 1, 0, 'trang', '2 kg', NULL, NULL),
(197, 'Vàng', 3, 25865339, 10496582, 'cat-3.jpg', '2024-05-31', 917, 0, 1, 4, 'den', '2 kg', NULL, NULL),
(198, 'Vàng', 2, 27411227, 11162520, 'product-9.jpg', '2024-05-31', 281, 0, 0, 3, 'cam', '1 kg', NULL, NULL),
(199, 'Bạc', 2, 27524861, 13993469, 'product-2.jpg', '2024-05-31', 1453, 1, 1, 2, 'vang', '1 kg', NULL, NULL),
(200, 'Vàng', 9, 22799281, 12785556, 'cat-3.jpg', '2024-05-31', 603, 1, 1, 2, 'den', '3 kg', NULL, NULL),
(201, 'Vàng', 9, 21809176, 10423555, 'cat-4.jpg', '2024-05-31', 407, 1, 0, 4, 'trang', '2 kg', NULL, NULL),
(202, 'Iphone', 7, 23274292, 13391413, 'cat-2.jpg', '2024-05-31', 452, 1, 1, 0, 'den', '2 kg', NULL, NULL),
(203, 'G12', 8, 28717913, 14087595, 'product-1.jpg', '2024-05-31', 727, 1, 0, 1, 'trang', '2 kg', NULL, NULL),
(204, 'Asus', 5, 24464591, 11304282, 'cat-1.jpg', '2024-05-31', 1820, 1, 0, 3, 'trang', '1 kg', NULL, NULL),
(205, 'Nước hoa nam', 10, 20329900, 13922747, 'product-3.jpg', '2024-05-31', 528, 1, 1, 1, 'den', '3 kg', NULL, NULL),
(206, 'Nước hoa nam', 3, 29674578, 10797552, 'cat-2.jpg', '2024-05-31', 437, 1, 0, 1, 'vang', '1 kg', NULL, NULL),
(207, 'G12', 10, 22362330, 13018803, 'cat-1.jpg', '2024-05-31', 798, 1, 1, 0, 'vang', '1 kg', NULL, NULL),
(208, 'Iphone', 9, 29531089, 13957850, 'product-7.jpg', '2024-05-31', 1930, 0, 1, 4, 'den', '1 kg', NULL, NULL),
(209, 'Vàng', 10, 27818064, 10849361, 'product-2.jpg', '2024-05-31', 961, 0, 1, 0, 'vang', '2 kg', NULL, NULL),
(210, 'G12', 6, 27909300, 12314291, 'product-2.jpg', '2024-05-31', 1843, 1, 1, 1, 'cam', '1 kg', NULL, NULL),
(211, 'Bạc', 8, 22739140, 11708587, 'cat-3.jpg', '2024-05-31', 1694, 1, 0, 0, 'den', '2 kg', NULL, NULL),
(212, 'Kim cương', 7, 28316990, 14655401, 'product-5.jpg', '2024-05-31', 1716, 1, 0, 2, 'vang', '2 kg', NULL, NULL),
(213, 'Nước hoa nam', 9, 25829117, 11916635, 'cat-4.jpg', '2024-05-31', 1958, 0, 0, 1, 'trang', '3 kg', NULL, NULL),
(214, 'Iphone', 4, 24379720, 12321885, 'product-2.jpg', '2024-05-31', 171, 1, 0, 4, 'vang', '1 kg', NULL, NULL),
(215, 'Mx97', 7, 28901844, 14179517, 'cat-2.jpg', '2024-05-31', 354, 0, 0, 0, 'vang', '2 kg', NULL, NULL),
(216, 'Vàng', 2, 27461778, 14558488, 'product-8.jpg', '2024-05-31', 1799, 0, 1, 0, 'den', '3 kg', NULL, NULL),
(217, 'G12', 4, 29796191, 11553775, 'product-2.jpg', '2024-05-31', 1341, 1, 1, 3, 'vang', '1 kg', NULL, NULL),
(218, 'Iphone', 1, 26758872, 14787636, 'cat-1.jpg', '2024-05-31', 1924, 1, 0, 2, 'cam', '1 kg', NULL, NULL),
(219, 'Banana', 9, 21991202, 12064014, 'cat-3.jpg', '2024-05-31', 289, 0, 0, 2, 'vang', '3 kg', NULL, NULL),
(220, 'Banana', 8, 22093838, 13037439, 'product-5.jpg', '2024-05-31', 879, 1, 0, 0, 'vang', '1 kg', NULL, NULL),
(221, 'Iphone', 6, 28065207, 12892432, 'cat-4.jpg', '2024-05-31', 320, 1, 1, 3, 'cam', '3 kg', NULL, NULL),
(222, 'Đầm phụ nữ', 7, 21695957, 13155989, 'product-7.jpg', '2024-05-31', 1938, 1, 0, 3, 'cam', '3 kg', NULL, NULL),
(223, 'Nước hoa nam', 3, 27787609, 10066001, 'product-7.jpg', '2024-05-31', 1334, 0, 1, 3, 'den', '1 kg', NULL, NULL),
(224, 'Asus', 6, 23892543, 10180522, 'product-2.jpg', '2024-05-31', 670, 1, 1, 0, 'trang', '2 kg', NULL, NULL),
(225, 'Iphone', 6, 21961748, 11037453, 'product-8.jpg', '2024-05-31', 1692, 0, 1, 2, 'den', '2 kg', NULL, NULL),
(226, 'Bạc', 7, 21130650, 14909682, 'product-6.jpg', '2024-05-31', 251, 0, 1, 0, 'den', '3 kg', NULL, NULL),
(227, 'Nước hoa nam', 4, 20466870, 12108991, 'cat-4.jpg', '2024-05-31', 825, 1, 0, 2, 'cam', '1 kg', NULL, NULL),
(228, 'Banana', 2, 23560978, 12521480, 'product-5.jpg', '2024-05-31', 503, 0, 0, 4, 'cam', '3 kg', NULL, NULL),
(229, 'Mx97', 8, 24645341, 12187029, 'cat-1.jpg', '2024-05-31', 468, 1, 1, 4, 'vang', '1 kg', NULL, NULL),
(230, 'Nước hoa nam', 4, 25157113, 11737504, 'product-7.jpg', '2024-05-31', 237, 1, 0, 2, 'den', '1 kg', NULL, NULL),
(231, 'Lenovo', 5, 25880844, 13559604, 'product-4.jpg', '2024-05-31', 544, 1, 0, 2, 'vang', '2 kg', NULL, NULL),
(232, 'Asus', 10, 24100642, 14455924, 'cat-3.jpg', '2024-05-31', 857, 1, 0, 1, 'cam', '1 kg', NULL, NULL),
(233, 'Mx97', 8, 22630930, 14297382, 'product-5.jpg', '2024-05-31', 1303, 1, 0, 1, 'cam', '1 kg', NULL, NULL),
(234, 'Banana', 5, 27065873, 11944350, 'product-8.jpg', '2024-05-31', 816, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(235, 'Nước hoa nữ', 2, 25797050, 10195773, 'product-3.jpg', '2024-05-31', 462, 0, 1, 2, 'cam', '2 kg', NULL, NULL),
(236, 'Camera', 10, 22602009, 14189125, 'cat-4.jpg', '2024-05-31', 85, 0, 0, 2, 'trang', '2 kg', NULL, NULL),
(237, 'G12', 1, 26531350, 11718500, 'product-8.jpg', '2024-05-31', 1992, 0, 0, 3, 'trang', '1 kg', NULL, NULL),
(238, 'Nước hoa nữ', 6, 29973822, 13302152, 'cat-1.jpg', '2024-05-31', 1668, 1, 0, 1, 'cam', '3 kg', NULL, NULL),
(239, 'Iphone', 10, 20088236, 11066388, 'product-4.jpg', '2024-05-31', 896, 0, 1, 0, 'trang', '1 kg', NULL, NULL),
(240, 'Banana', 8, 25814270, 13094809, 'product-9.jpg', '2024-05-31', 1113, 1, 1, 1, 'vang', '1 kg', NULL, NULL),
(241, 'Nước hoa nam', 5, 27767294, 12166486, 'product-2.jpg', '2024-05-31', 106, 1, 1, 0, 'den', '3 kg', NULL, NULL),
(242, 'Asus', 2, 25796924, 12294493, 'cat-4.jpg', '2024-05-31', 970, 0, 0, 2, 'den', '1 kg', NULL, NULL),
(243, 'Banana', 3, 24850524, 14102395, 'product-2.jpg', '2024-05-31', 1601, 0, 1, 1, 'cam', '3 kg', NULL, NULL),
(244, 'G12', 9, 25487604, 10149196, 'product-9.jpg', '2024-05-31', 1357, 1, 1, 0, 'den', '1 kg', NULL, NULL),
(245, 'Asus', 6, 28379282, 10765168, 'cat-4.jpg', '2024-05-31', 828, 1, 0, 0, 'den', '2 kg', NULL, NULL),
(246, 'Nước hoa nam', 2, 22999710, 14200276, 'product-3.jpg', '2024-05-31', 169, 0, 1, 1, 'cam', '2 kg', NULL, NULL),
(247, 'Banana', 8, 27919680, 11476434, 'product-2.jpg', '2024-05-31', 220, 1, 0, 3, 'den', '2 kg', NULL, NULL),
(248, 'Đầm phụ nữ', 8, 29089944, 14846271, 'product-6.jpg', '2024-05-31', 633, 1, 1, 4, 'cam', '3 kg', NULL, NULL),
(249, 'Vàng', 5, 27934209, 12325722, 'product-1.jpg', '2024-05-31', 1411, 0, 1, 4, 'cam', '3 kg', NULL, NULL),
(250, 'Nước hoa nam', 4, 26227969, 12219464, 'product-6.jpg', '2024-05-31', 437, 1, 1, 3, 'trang', '3 kg', NULL, NULL),
(251, 'Nước hoa nam', 4, 28365955, 14682175, 'cat-2.jpg', '2024-05-31', 1757, 1, 1, 4, 'trang', '2 kg', NULL, NULL),
(252, 'Nước hoa nữ', 3, 24849017, 12816318, 'product-5.jpg', '2024-05-31', 677, 0, 0, 4, 'cam', '3 kg', NULL, NULL),
(253, 'Banana', 8, 29963786, 11395005, 'product-1.jpg', '2024-05-31', 197, 0, 0, 2, 'cam', '3 kg', NULL, NULL),
(254, 'Kim cương', 4, 29697587, 14389975, 'product-7.jpg', '2024-05-31', 1731, 1, 0, 3, 'trang', '1 kg', NULL, NULL),
(255, 'Iphone', 9, 22729930, 14945787, 'cat-4.jpg', '2024-05-31', 1925, 0, 0, 3, 'cam', '3 kg', NULL, NULL),
(257, 'Lenovo', 3, 24208755, 12298015, 'product-1.jpg', '2024-05-31', 1292, 1, 1, 4, 'den', '2 kg', NULL, NULL),
(258, 'Asus', 1, 29487734, 14938429, 'product-1.jpg', '2024-05-31', 1606, 0, 1, 0, 'den', '1 kg', NULL, NULL),
(259, 'Camera', 4, 22279373, 14113249, 'product-2.jpg', '2024-05-31', 1801, 1, 0, 0, 'trang', '1 kg', NULL, NULL),
(260, 'Vàng', 4, 24064816, 11140011, 'product-9.jpg', '2024-05-31', 1531, 0, 1, 1, 'cam', '2 kg', NULL, NULL),
(261, 'Mx97', 1, 26081438, 11641208, 'cat-2.jpg', '2024-05-31', 1875, 0, 0, 2, 'vang', '1 kg', NULL, NULL),
(262, 'Lenovo', 6, 22055643, 10253806, 'product-1.jpg', '2024-05-31', 1618, 1, 0, 2, 'trang', '3 kg', NULL, NULL),
(263, 'Kim cương', 5, 28808587, 13983269, 'product-2.jpg', '2024-05-31', 742, 0, 0, 3, 'den', '1 kg', NULL, NULL),
(264, 'Mx97', 4, 22460252, 11557567, 'product-2.jpg', '2024-05-31', 53, 0, 1, 1, 'trang', '3 kg', NULL, NULL),
(265, 'Nước hoa nữ', 2, 26574319, 11164204, 'cat-1.jpg', '2024-05-31', 38, 1, 1, 3, 'trang', '3 kg', NULL, NULL),
(266, 'Bạc', 7, 25566736, 10661667, 'cat-2.jpg', '2024-05-31', 1242, 1, 0, 3, 'cam', '2 kg', NULL, NULL),
(267, 'Iphone', 5, 26020336, 11174245, 'cat-1.jpg', '2024-05-31', 306, 0, 0, 2, 'vang', '3 kg', NULL, NULL),
(268, 'Bạc', 10, 26920687, 14407112, 'product-5.jpg', '2024-05-31', 1400, 0, 1, 4, 'vang', '3 kg', NULL, NULL),
(269, 'G12', 2, 21689164, 10633012, 'product-1.jpg', '2024-05-31', 1142, 1, 0, 4, 'trang', '3 kg', NULL, NULL),
(270, 'Iphone', 6, 27083653, 11385130, 'product-2.jpg', '2024-05-31', 1271, 0, 0, 4, 'trang', '3 kg', NULL, NULL),
(271, 'Camera', 9, 22647182, 11702854, 'cat-3.jpg', '2024-05-31', 1290, 0, 1, 4, 'vang', '2 kg', NULL, NULL),
(272, 'Asus', 1, 27921431, 14854660, 'cat-2.jpg', '2024-05-31', 1701, 0, 1, 0, 'cam', '2 kg', NULL, NULL),
(273, 'Lenovo', 3, 21783626, 13502177, 'product-6.jpg', '2024-05-31', 1584, 0, 1, 4, 'cam', '1 kg', NULL, NULL),
(274, 'Lenovo', 4, 27950164, 13340374, 'product-6.jpg', '2024-05-31', 1018, 0, 1, 0, 'vang', '2 kg', NULL, NULL),
(275, 'Asus', 7, 25452322, 14529202, 'cat-3.jpg', '2024-05-31', 288, 1, 1, 0, 'cam', '1 kg', NULL, NULL),
(276, 'Apple', 2, 23294500, 13022278, 'cat-4.jpg', '2024-05-31', 418, 1, 0, 2, 'den', '2 kg', NULL, NULL),
(277, 'Asus', 4, 25523204, 10853285, 'product-6.jpg', '2024-05-31', 856, 1, 1, 4, 'cam', '3 kg', NULL, NULL),
(278, 'Kim cương', 1, 24915688, 13241855, 'cat-1.jpg', '2024-05-31', 654, 1, 1, 4, 'den', '2 kg', NULL, NULL),
(279, 'Banana', 4, 26658264, 12063476, 'cat-3.jpg', '2024-05-31', 631, 0, 0, 0, 'trang', '1 kg', NULL, NULL),
(280, 'Bạc', 5, 21941726, 13828585, 'product-9.jpg', '2024-05-31', 1159, 0, 1, 1, 'trang', '2 kg', NULL, NULL),
(281, 'Vàng', 10, 27516303, 12499912, 'product-2.jpg', '2024-05-31', 214, 0, 0, 1, 'den', '3 kg', NULL, NULL),
(282, 'Camera', 10, 29413309, 14171684, 'product-4.jpg', '2024-05-31', 1504, 1, 0, 3, 'trang', '1 kg', NULL, NULL),
(283, 'Bạc', 7, 25303789, 11164040, 'cat-3.jpg', '2024-05-31', 433, 1, 0, 3, 'vang', '3 kg', NULL, NULL),
(284, 'Đầm phụ nữ', 10, 29078904, 14243062, 'product-8.jpg', '2024-05-31', 1919, 0, 1, 1, 'den', '3 kg', NULL, NULL),
(285, 'G12', 2, 24316538, 13974568, 'cat-2.jpg', '2024-05-31', 1950, 0, 0, 0, 'den', '1 kg', NULL, NULL),
(286, 'Asus', 9, 26618534, 12473513, 'cat-3.jpg', '2024-05-31', 475, 0, 1, 4, 'trang', '1 kg', NULL, NULL),
(287, 'Lenovo', 6, 29136222, 14167840, 'product-9.jpg', '2024-05-31', 1424, 1, 0, 1, 'trang', '1 kg', NULL, NULL),
(288, 'Asus', 7, 24094532, 12229169, 'cat-3.jpg', '2024-05-31', 726, 0, 0, 3, 'trang', '1 kg', NULL, NULL),
(289, 'Kim cương', 8, 25307036, 12376539, 'product-9.jpg', '2024-05-31', 1070, 1, 0, 3, 'den', '1 kg', NULL, NULL),
(290, 'Lenovo', 9, 20036490, 14608988, 'cat-2.jpg', '2024-05-31', 316, 1, 1, 1, 'trang', '1 kg', NULL, NULL),
(291, 'G12', 5, 29694732, 14154449, 'product-7.jpg', '2024-05-31', 1586, 0, 1, 1, 'vang', '2 kg', NULL, NULL),
(292, 'Camera', 1, 25746043, 10134766, 'product-3.jpg', '2024-05-31', 243, 1, 0, 3, 'den', '3 kg', NULL, NULL),
(293, 'Banana', 2, 23987488, 12973204, 'product-2.jpg', '2024-05-31', 56, 0, 0, 0, 'cam', '2 kg', NULL, NULL),
(294, 'G12', 1, 25831950, 13174977, 'product-5.jpg', '2024-05-31', 1333, 0, 1, 4, 'den', '2 kg', NULL, NULL),
(295, 'Vàng', 8, 21250242, 14518797, 'product-4.jpg', '2024-05-31', 1749, 0, 0, 1, 'cam', '1 kg', NULL, NULL),
(296, 'Iphone', 1, 25817941, 14248641, 'product-4.jpg', '2024-05-31', 1030, 0, 0, 0, 'cam', '1 kg', NULL, NULL),
(297, 'Apple', 9, 23004462, 11171282, 'product-2.jpg', '2024-05-31', 1614, 0, 1, 0, 'trang', '2 kg', NULL, NULL),
(298, 'Banana', 3, 20469694, 12796075, 'cat-3.jpg', '2024-05-31', 1051, 1, 0, 3, 'cam', '3 kg', NULL, NULL),
(299, 'Đầm phụ nữ', 1, 27794575, 13978418, 'cat-4.jpg', '2024-05-31', 688, 1, 0, 4, 'vang', '1 kg', NULL, NULL),
(300, 'Nước hoa nữ', 10, 20296898, 13786606, 'cat-1.jpg', '2024-05-31', 1113, 0, 1, 3, 'vang', '2 kg', NULL, NULL),
(301, 'Bạc', 3, 21332752, 10606945, 'product-8.jpg', '2024-05-31', 559, 0, 1, 1, 'den', '2 kg', NULL, NULL),
(302, 'Nước hoa nam', 10, 21127684, 14481861, 'product-8.jpg', '2024-05-31', 831, 0, 0, 2, 'cam', '1 kg', NULL, NULL),
(303, 'Asus', 1, 28548601, 11422537, 'cat-2.jpg', '2024-05-31', 840, 0, 1, 4, 'den', '3 kg', NULL, NULL),
(304, 'Lenovo', 10, 21554918, 13441572, 'cat-4.jpg', '2024-05-31', 1397, 1, 0, 3, 'cam', '2 kg', NULL, NULL),
(305, 'Lenovo', 3, 27705724, 10664170, 'product-6.jpg', '2024-05-31', 931, 0, 0, 2, 'vang', '1 kg', NULL, NULL),
(306, 'Nước hoa nữ', 1, 20977015, 12583854, 'cat-1.jpg', '2024-05-31', 174, 1, 0, 3, 'vang', '1 kg', NULL, NULL),
(307, 'Lenovo', 3, 20110874, 10428395, 'product-6.jpg', '2024-05-31', 1609, 0, 0, 4, 'cam', '2 kg', NULL, NULL),
(308, 'Iphone', 4, 25466515, 10224999, 'product-8.jpg', '2024-05-31', 1941, 1, 1, 0, 'den', '1 kg', NULL, NULL),
(309, 'Vàng', 5, 26166359, 14051712, 'product-3.jpg', '2024-05-31', 119, 0, 1, 4, 'trang', '1 kg', NULL, NULL),
(310, 'Lenovo', 2, 22290118, 12291013, 'product-4.jpg', '2024-05-31', 446, 0, 0, 1, 'vang', '3 kg', NULL, NULL),
(311, 'Banana', 1, 24521127, 11896824, 'product-2.jpg', '2024-05-31', 1901, 0, 1, 2, 'trang', '2 kg', NULL, NULL),
(312, 'Kim cương', 6, 28520211, 10490145, 'cat-3.jpg', '2024-05-31', 1249, 1, 0, 0, 'den', '2 kg', NULL, NULL),
(313, 'Vàng', 5, 28857313, 11664719, 'product-9.jpg', '2024-05-31', 565, 1, 0, 1, 'trang', '3 kg', NULL, NULL),
(314, 'Nước hoa nam', 2, 25463813, 14516784, 'product-9.jpg', '2024-05-31', 1679, 1, 1, 3, 'den', '3 kg', NULL, NULL),
(315, 'Mx97', 2, 25187678, 12944989, 'product-6.jpg', '2024-05-31', 385, 1, 1, 3, 'trang', '1 kg', NULL, NULL),
(316, 'Nước hoa nam', 8, 28389255, 10672823, 'product-5.jpg', '2024-05-31', 1, 1, 0, 2, 'cam', '2 kg', NULL, NULL),
(317, 'Asus', 9, 23264848, 11321123, 'product-1.jpg', '2024-05-31', 188, 1, 1, 0, 'trang', '1 kg', NULL, NULL),
(318, 'G12', 1, 20420004, 14706269, 'cat-4.jpg', '2024-05-31', 1769, 0, 1, 2, 'trang', '1 kg', NULL, NULL),
(319, 'G12', 4, 22886710, 13658199, 'product-2.jpg', '2024-05-31', 1993, 0, 1, 1, 'vang', '3 kg', NULL, NULL),
(320, 'Nước hoa nam', 8, 22471938, 12466765, 'product-8.jpg', '2024-05-31', 588, 1, 0, 1, 'den', '2 kg', NULL, NULL),
(321, 'Bạc', 5, 21194323, 10626778, 'cat-4.jpg', '2024-05-31', 353, 0, 1, 3, 'cam', '1 kg', NULL, NULL),
(322, 'Bạc', 9, 28317147, 11356157, 'product-4.jpg', '2024-05-31', 862, 0, 1, 2, 'cam', '1 kg', NULL, NULL),
(323, 'Vàng', 8, 25527631, 11208284, 'product-1.jpg', '2024-05-31', 1537, 1, 1, 1, 'trang', '1 kg', NULL, NULL),
(324, 'Đầm phụ nữ', 3, 23732968, 11197842, 'product-7.jpg', '2024-05-31', 570, 0, 1, 4, 'trang', '3 kg', NULL, NULL),
(325, 'Kim cương', 5, 25819656, 14888065, 'cat-4.jpg', '2024-05-31', 975, 1, 0, 3, 'cam', '3 kg', NULL, NULL),
(326, 'Bạc', 2, 25194603, 13447712, 'cat-1.jpg', '2024-05-31', 152, 0, 1, 3, 'den', '3 kg', NULL, NULL),
(327, 'Vàng', 2, 24639251, 14230746, 'cat-2.jpg', '2024-05-31', 1576, 1, 1, 4, 'cam', '3 kg', NULL, NULL),
(328, 'Kim cương', 4, 20853736, 14669147, 'cat-4.jpg', '2024-05-31', 1295, 1, 1, 3, 'den', '3 kg', NULL, NULL),
(329, 'Nước hoa nam', 2, 25796649, 10829635, 'cat-3.jpg', '2024-05-31', 264, 0, 0, 1, 'vang', '2 kg', NULL, NULL),
(330, 'Apple', 1, 20586237, 14660882, 'product-4.jpg', '2024-05-31', 1734, 1, 0, 4, 'den', '1 kg', NULL, NULL),
(331, 'Đầm phụ nữ', 6, 29673697, 11133347, 'product-3.jpg', '2024-05-31', 1730, 1, 1, 2, 'den', '1 kg', NULL, NULL),
(332, 'Camera', 9, 24594929, 13512044, 'product-5.jpg', '2024-05-31', 1335, 1, 0, 3, 'trang', '3 kg', NULL, NULL),
(333, 'Lenovo', 1, 20921719, 14901976, 'product-8.jpg', '2024-05-31', 811, 0, 0, 2, 'den', '3 kg', NULL, NULL),
(334, 'Lenovo', 8, 22366612, 13238266, 'product-2.jpg', '2024-05-31', 1659, 1, 1, 0, 'vang', '1 kg', NULL, NULL),
(335, 'Nước hoa nam', 8, 27566725, 14743023, 'product-4.jpg', '2024-05-31', 91, 0, 0, 2, 'trang', '3 kg', NULL, NULL),
(336, 'Apple', 1, 27872878, 11513937, 'product-2.jpg', '2024-05-31', 1128, 1, 1, 3, 'vang', '1 kg', NULL, NULL),
(337, 'Asus', 10, 20243817, 13090908, 'cat-4.jpg', '2024-05-31', 731, 0, 0, 3, 'trang', '3 kg', NULL, NULL),
(338, 'Iphone', 3, 26769418, 13823380, 'cat-4.jpg', '2024-05-31', 1112, 0, 1, 1, 'trang', '3 kg', NULL, NULL),
(339, 'Lenovo', 1, 23135595, 12274824, 'product-8.jpg', '2024-05-31', 1780, 0, 1, 2, 'trang', '2 kg', NULL, NULL),
(340, 'Nước hoa nữ', 4, 20956698, 14069504, 'cat-3.jpg', '2024-05-31', 1143, 0, 0, 2, 'vang', '1 kg', NULL, NULL),
(341, 'Nước hoa nam', 1, 22484852, 13736713, 'product-8.jpg', '2024-05-31', 1674, 1, 1, 1, 'trang', '2 kg', NULL, NULL),
(342, 'Mx97', 8, 22718055, 14589407, 'product-9.jpg', '2024-05-31', 1065, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(343, 'Asus', 7, 26409870, 13794889, 'cat-1.jpg', '2024-05-31', 1433, 0, 0, 1, 'cam', '1 kg', NULL, NULL),
(344, 'Lenovo', 1, 25023644, 13347410, 'product-8.jpg', '2024-05-31', 269, 1, 1, 3, 'vang', '3 kg', NULL, NULL),
(345, 'Mx97', 1, 21700255, 11722180, 'product-5.jpg', '2024-05-31', 561, 0, 0, 3, 'trang', '1 kg', NULL, NULL),
(346, 'Mx97', 10, 25765554, 12737509, 'product-2.jpg', '2024-05-31', 377, 1, 0, 4, 'trang', '1 kg', NULL, NULL),
(347, 'G12', 6, 23395608, 11171276, 'product-5.jpg', '2024-05-31', 480, 0, 1, 4, 'den', '3 kg', NULL, NULL),
(348, 'Bạc', 5, 25686079, 10569787, 'cat-4.jpg', '2024-05-31', 348, 0, 1, 3, 'den', '1 kg', NULL, NULL),
(349, 'Nước hoa nữ', 1, 25047374, 13826328, 'product-7.jpg', '2024-05-31', 1499, 0, 1, 2, 'cam', '1 kg', NULL, NULL),
(350, 'Nước hoa nam', 2, 21235497, 12750863, 'cat-2.jpg', '2024-05-31', 345, 0, 0, 3, 'den', '3 kg', NULL, NULL),
(351, 'Lenovo', 9, 26784356, 11649964, 'cat-3.jpg', '2024-05-31', 524, 1, 1, 1, 'den', '2 kg', NULL, NULL),
(352, 'Mx97', 8, 24220402, 14452266, 'product-3.jpg', '2024-05-31', 1182, 0, 1, 3, 'den', '2 kg', NULL, NULL),
(353, 'Lenovo', 6, 21922790, 12026369, 'cat-1.jpg', '2024-05-31', 1493, 1, 0, 4, 'vang', '3 kg', NULL, NULL),
(354, 'Mx97', 9, 20245655, 10093847, 'cat-1.jpg', '2024-05-31', 1798, 1, 1, 1, 'den', '1 kg', NULL, NULL),
(355, 'Kim cương', 5, 29890733, 10790087, 'product-7.jpg', '2024-05-31', 1529, 1, 0, 0, 'trang', '2 kg', NULL, NULL),
(356, 'Nước hoa nam', 8, 21602931, 13562657, 'cat-2.jpg', '2024-05-31', 749, 1, 1, 1, 'den', '1 kg', NULL, NULL),
(357, 'Asus', 1, 24225829, 10615097, 'product-4.jpg', '2024-05-31', 1181, 0, 1, 3, 'trang', '3 kg', NULL, NULL),
(358, 'Bạc', 5, 27831089, 13766568, 'product-5.jpg', '2024-05-31', 1700, 0, 0, 1, 'cam', '2 kg', NULL, NULL),
(359, 'Camera', 2, 29244341, 10957223, 'product-2.jpg', '2024-05-31', 1442, 0, 0, 1, 'vang', '1 kg', NULL, NULL),
(360, 'Kim cương', 8, 27274206, 13280773, 'product-7.jpg', '2024-05-31', 583, 0, 0, 1, 'trang', '3 kg', NULL, NULL),
(361, 'Camera', 7, 21264671, 10404785, 'product-1.jpg', '2024-05-31', 520, 1, 1, 1, 'cam', '2 kg', NULL, NULL),
(362, 'Camera', 4, 27997244, 11237648, 'product-4.jpg', '2024-05-31', 87, 0, 0, 2, 'den', '3 kg', NULL, NULL),
(363, 'Mx97', 5, 20698565, 12834340, 'product-7.jpg', '2024-05-31', 1367, 1, 1, 3, 'vang', '1 kg', NULL, NULL),
(364, 'Banana', 2, 25736488, 10178222, 'product-4.jpg', '2024-05-31', 740, 1, 0, 3, 'vang', '2 kg', NULL, NULL),
(365, 'Lenovo', 3, 22703712, 13682560, 'product-4.jpg', '2024-05-31', 1957, 1, 1, 2, 'vang', '2 kg', NULL, NULL),
(366, 'Nước hoa nam', 9, 25932044, 12095358, 'product-6.jpg', '2024-05-31', 1020, 1, 0, 2, 'trang', '2 kg', NULL, NULL),
(367, 'Kim cương', 1, 24622806, 13751505, 'product-4.jpg', '2024-05-31', 150, 0, 0, 3, 'cam', '2 kg', NULL, NULL),
(368, 'Nước hoa nam', 6, 21649165, 13018337, 'cat-4.jpg', '2024-05-31', 1468, 1, 0, 3, 'trang', '1 kg', NULL, NULL),
(369, 'Đầm phụ nữ', 8, 20189376, 13149719, 'product-8.jpg', '2024-05-31', 67, 0, 0, 0, 'vang', '2 kg', NULL, NULL),
(370, 'Nước hoa nữ', 8, 28944289, 10460006, 'product-2.jpg', '2024-05-31', 1890, 1, 0, 0, 'den', '3 kg', NULL, NULL),
(371, 'Đầm phụ nữ', 3, 27228069, 12543745, 'cat-3.jpg', '2024-05-31', 843, 1, 0, 0, 'vang', '2 kg', NULL, NULL),
(372, 'Nước hoa nữ', 8, 23331791, 14298389, 'cat-3.jpg', '2024-05-31', 1642, 0, 1, 2, 'trang', '2 kg', NULL, NULL),
(373, 'G12', 9, 27155820, 12584297, 'product-7.jpg', '2024-05-31', 1733, 1, 1, 0, 'cam', '3 kg', NULL, NULL),
(374, 'Lenovo', 10, 22422645, 11723918, 'product-7.jpg', '2024-05-31', 1914, 0, 0, 2, 'trang', '2 kg', NULL, NULL),
(375, 'Nước hoa nữ', 5, 28243518, 14757189, 'product-7.jpg', '2024-05-31', 583, 0, 1, 3, 'cam', '1 kg', NULL, NULL),
(376, 'Vàng', 1, 25936307, 10515149, 'cat-2.jpg', '2024-05-31', 1017, 1, 1, 4, 'cam', '1 kg', NULL, NULL),
(377, 'Apple', 2, 22138361, 14722676, 'cat-4.jpg', '2024-05-31', 1773, 0, 0, 3, 'vang', '2 kg', NULL, NULL),
(378, 'Vàng', 2, 24737205, 13194802, 'product-6.jpg', '2024-05-31', 1427, 1, 0, 0, 'den', '3 kg', NULL, NULL),
(379, 'Đầm phụ nữ', 6, 24541586, 10948142, 'cat-2.jpg', '2024-05-31', 1079, 1, 1, 4, 'trang', '3 kg', NULL, NULL),
(380, 'Iphone', 2, 23865506, 12090536, 'product-7.jpg', '2024-05-31', 1189, 1, 1, 0, 'vang', '3 kg', NULL, NULL),
(381, 'Camera', 5, 21082984, 10381159, 'cat-3.jpg', '2024-05-31', 1865, 1, 1, 2, 'vang', '2 kg', NULL, NULL),
(382, 'Bạc', 3, 27702920, 12287306, 'product-4.jpg', '2024-05-31', 261, 0, 0, 4, 'den', '2 kg', NULL, NULL),
(383, 'Nước hoa nam', 5, 28470079, 13439316, 'product-6.jpg', '2024-05-31', 1328, 0, 1, 1, 'cam', '1 kg', NULL, NULL),
(384, 'Lenovo', 4, 23025055, 14518179, 'product-5.jpg', '2024-05-31', 1816, 0, 0, 4, 'vang', '1 kg', NULL, NULL),
(385, 'Lenovo', 9, 26320702, 11255879, 'cat-2.jpg', '2024-05-31', 968, 1, 0, 2, 'den', '1 kg', NULL, NULL),
(386, 'Bạc', 3, 29348523, 12131712, 'cat-1.jpg', '2024-05-31', 197, 0, 1, 4, 'den', '3 kg', NULL, NULL),
(387, 'G12', 6, 29917653, 10323673, 'cat-3.jpg', '2024-05-31', 1345, 1, 1, 3, 'cam', '1 kg', NULL, NULL),
(388, 'Nước hoa nữ', 7, 25247912, 14266869, 'cat-1.jpg', '2024-05-31', 1703, 1, 0, 3, 'vang', '3 kg', NULL, NULL),
(389, 'Kim cương', 9, 28952195, 10579104, 'product-6.jpg', '2024-05-31', 1734, 1, 0, 0, 'trang', '3 kg', NULL, NULL),
(390, 'Iphone', 2, 25057780, 11902746, 'cat-2.jpg', '2024-05-31', 1937, 1, 1, 4, 'trang', '2 kg', NULL, NULL),
(391, 'Apple', 7, 27947610, 14260520, 'product-2.jpg', '2024-05-31', 1511, 0, 0, 4, 'den', '3 kg', NULL, NULL),
(392, 'Asus', 10, 24426846, 14704094, 'product-4.jpg', '2024-05-31', 519, 0, 1, 1, 'den', '3 kg', NULL, NULL),
(393, 'Nước hoa nam', 1, 20782139, 14443095, 'cat-3.jpg', '2024-05-31', 1632, 1, 0, 2, 'den', '1 kg', NULL, NULL),
(394, 'Vàng', 2, 25115423, 12839189, 'product-4.jpg', '2024-05-31', 1084, 0, 1, 0, 'trang', '1 kg', NULL, NULL),
(395, 'Nước hoa nam', 3, 26439775, 11966258, 'product-7.jpg', '2024-05-31', 618, 1, 0, 2, 'den', '3 kg', NULL, NULL),
(396, 'Lenovo', 6, 29285805, 14694771, 'product-9.jpg', '2024-05-31', 793, 0, 0, 1, 'cam', '3 kg', NULL, NULL),
(397, 'Vàng', 2, 24143915, 12522853, 'product-4.jpg', '2024-05-31', 1653, 1, 1, 4, 'den', '1 kg', NULL, NULL),
(398, 'Banana', 10, 28186308, 10373471, 'product-3.jpg', '2024-05-31', 388, 1, 1, 1, 'trang', '3 kg', NULL, NULL),
(399, 'Vàng', 4, 25901026, 12170004, 'product-4.jpg', '2024-05-31', 176, 1, 1, 1, 'vang', '3 kg', NULL, NULL),
(400, 'Mx97', 9, 27667296, 13180485, 'product-7.jpg', '2024-05-31', 1954, 0, 1, 4, 'den', '1 kg', NULL, NULL),
(401, 'G12', 7, 28589930, 11737936, 'product-4.jpg', '2024-05-31', 1485, 1, 0, 0, 'vang', '3 kg', NULL, NULL),
(402, 'Iphone', 4, 28233702, 11211599, 'cat-2.jpg', '2024-05-31', 1426, 0, 0, 3, 'vang', '1 kg', NULL, NULL),
(403, 'Mx97', 10, 26096188, 13038368, 'cat-2.jpg', '2024-05-31', 1179, 0, 1, 3, 'cam', '3 kg', NULL, NULL),
(404, 'Nước hoa nữ', 2, 21858857, 12555430, 'product-6.jpg', '2024-05-31', 1069, 0, 0, 0, 'vang', '1 kg', NULL, NULL),
(405, 'Camera', 9, 29766376, 13046251, 'product-2.jpg', '2024-05-31', 401, 1, 1, 3, 'vang', '2 kg', NULL, NULL),
(406, 'Apple', 3, 29304804, 10312542, 'cat-3.jpg', '2024-05-31', 569, 0, 1, 1, 'den', '1 kg', NULL, NULL),
(407, 'G12', 9, 20753225, 10452362, 'product-5.jpg', '2024-05-31', 879, 1, 1, 4, 'trang', '2 kg', NULL, NULL),
(408, 'Bạc', 1, 26381325, 10016893, 'cat-3.jpg', '2024-05-31', 1625, 0, 1, 4, 'trang', '3 kg', NULL, NULL),
(409, 'Vàng', 6, 26350068, 11908334, 'product-3.jpg', '2024-05-31', 1440, 1, 1, 2, 'cam', '3 kg', NULL, NULL),
(410, 'Vàng', 4, 28080496, 14843324, 'cat-2.jpg', '2024-05-31', 1755, 1, 1, 1, 'vang', '2 kg', NULL, NULL),
(411, 'Nước hoa nam', 10, 23152253, 13045162, 'product-3.jpg', '2024-05-31', 1081, 1, 1, 1, 'den', '1 kg', NULL, NULL),
(412, 'Mx97', 8, 21341927, 14720490, 'product-4.jpg', '2024-05-31', 263, 0, 0, 2, 'trang', '2 kg', NULL, NULL),
(413, 'Mx97', 7, 25270707, 11107434, 'cat-1.jpg', '2024-05-31', 992, 0, 1, 3, 'trang', '1 kg', NULL, NULL),
(414, 'G12', 2, 25596654, 11424932, 'product-1.jpg', '2024-05-31', 1500, 0, 0, 2, 'trang', '3 kg', NULL, NULL),
(415, 'Vàng', 5, 28185579, 11955104, 'cat-3.jpg', '2024-05-31', 1345, 0, 1, 0, 'vang', '3 kg', NULL, NULL),
(416, 'Bạc', 10, 22462875, 11727076, 'product-4.jpg', '2024-05-31', 1133, 1, 0, 0, 'trang', '1 kg', NULL, NULL),
(417, 'Lenovo', 1, 27244966, 12567937, 'product-1.jpg', '2024-05-31', 498, 0, 0, 2, 'cam', '1 kg', NULL, NULL),
(418, 'Kim cương', 8, 24742246, 12395229, 'product-6.jpg', '2024-05-31', 1798, 0, 0, 3, 'vang', '2 kg', NULL, NULL),
(419, 'Lenovo', 9, 24262377, 12705508, 'product-3.jpg', '2024-05-31', 687, 0, 0, 1, 'cam', '3 kg', NULL, NULL),
(420, 'Banana', 6, 26645769, 14920261, 'product-6.jpg', '2024-05-31', 467, 0, 1, 2, 'cam', '3 kg', NULL, NULL),
(421, 'Nước hoa nữ', 8, 21121671, 13785283, 'product-1.jpg', '2024-05-31', 933, 0, 1, 4, 'vang', '1 kg', NULL, NULL),
(422, 'Asus', 4, 26295282, 14146749, 'cat-4.jpg', '2024-05-31', 316, 1, 0, 2, 'den', '2 kg', NULL, NULL),
(423, 'Vàng', 2, 26372598, 10690264, 'product-2.jpg', '2024-05-31', 1155, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(424, 'Iphone', 3, 27274125, 13565823, 'product-3.jpg', '2024-05-31', 915, 0, 0, 1, 'trang', '1 kg', NULL, NULL),
(425, 'Asus', 9, 28813112, 12597982, 'cat-3.jpg', '2024-05-31', 1630, 0, 0, 2, 'cam', '2 kg', NULL, NULL),
(426, 'Iphone', 5, 26790517, 14619599, 'product-8.jpg', '2024-05-31', 1705, 0, 0, 4, 'cam', '1 kg', NULL, NULL),
(427, 'Camera', 3, 25280946, 14047662, 'product-4.jpg', '2024-05-31', 280, 0, 0, 2, 'vang', '3 kg', NULL, NULL),
(428, 'Asus', 2, 23424292, 12366164, 'cat-1.jpg', '2024-05-31', 220, 1, 1, 0, 'cam', '1 kg', NULL, NULL),
(429, 'Lenovo', 5, 25022789, 13164068, 'cat-3.jpg', '2024-05-31', 139, 1, 1, 2, 'trang', '3 kg', NULL, NULL),
(430, 'Iphone', 10, 26254410, 14799135, 'product-6.jpg', '2024-05-31', 866, 0, 0, 0, 'trang', '2 kg', NULL, NULL),
(431, 'Apple', 5, 23123111, 12507655, 'cat-4.jpg', '2024-05-31', 1374, 1, 1, 2, 'cam', '1 kg', NULL, NULL),
(432, 'G12', 5, 29210793, 14623324, 'cat-4.jpg', '2024-05-31', 1595, 0, 0, 0, 'vang', '3 kg', NULL, NULL),
(433, 'Đầm phụ nữ', 6, 22934835, 11220300, 'product-3.jpg', '2024-05-31', 530, 0, 0, 0, 'cam', '1 kg', NULL, NULL),
(434, 'Kim cương', 1, 23603156, 12101302, 'cat-3.jpg', '2024-05-31', 977, 1, 1, 0, 'cam', '3 kg', NULL, NULL),
(435, 'Bạc', 6, 26792276, 13693770, 'product-9.jpg', '2024-05-31', 290, 1, 0, 4, 'vang', '1 kg', NULL, NULL),
(436, 'Camera', 10, 24875592, 12458517, 'product-8.jpg', '2024-05-31', 46, 0, 0, 3, 'den', '2 kg', NULL, NULL),
(437, 'Apple', 7, 27920008, 12847347, 'product-2.jpg', '2024-05-31', 1167, 1, 1, 2, 'den', '2 kg', NULL, NULL),
(438, 'Kim cương', 5, 27700523, 13186494, 'cat-4.jpg', '2024-05-31', 877, 1, 0, 0, 'vang', '2 kg', NULL, NULL),
(439, 'Mx97', 10, 25316852, 14420319, 'product-3.jpg', '2024-05-31', 323, 1, 1, 0, 'vang', '1 kg', NULL, NULL),
(440, 'Lenovo', 2, 25140014, 12354542, 'product-6.jpg', '2024-05-31', 1460, 0, 1, 0, 'cam', '1 kg', NULL, NULL),
(441, 'Nước hoa nữ', 9, 24855868, 11385718, 'product-9.jpg', '2024-05-31', 1538, 1, 0, 0, 'vang', '3 kg', NULL, NULL),
(442, 'Bạc', 5, 25261605, 11209674, 'product-5.jpg', '2024-05-31', 991, 1, 1, 1, 'cam', '1 kg', NULL, NULL),
(443, 'Banana', 5, 26510204, 10952394, 'product-6.jpg', '2024-05-31', 1565, 0, 1, 4, 'cam', '1 kg', NULL, NULL),
(444, 'Bạc', 8, 27465202, 13516593, 'product-5.jpg', '2024-05-31', 411, 0, 1, 0, 'cam', '3 kg', NULL, NULL),
(445, 'Nước hoa nữ', 1, 22988044, 10167805, 'cat-3.jpg', '2024-05-31', 695, 1, 0, 3, 'vang', '1 kg', NULL, NULL),
(446, 'Kim cương', 3, 21979048, 11183897, 'product-5.jpg', '2024-05-31', 500, 0, 1, 1, 'den', '2 kg', NULL, NULL),
(447, 'Lenovo', 9, 26697981, 10373511, 'cat-1.jpg', '2024-05-31', 1433, 0, 0, 2, 'vang', '3 kg', NULL, NULL),
(448, 'Đầm phụ nữ', 4, 21596432, 11027689, 'product-3.jpg', '2024-05-31', 212, 1, 1, 3, 'vang', '1 kg', NULL, NULL),
(449, 'Bạc', 3, 20386225, 10346321, 'cat-1.jpg', '2024-05-31', 416, 1, 0, 3, 'cam', '2 kg', NULL, NULL),
(450, 'G12', 5, 27342117, 12469476, 'cat-1.jpg', '2024-05-31', 925, 0, 0, 3, 'trang', '1 kg', NULL, NULL),
(451, 'Asus', 2, 28553938, 11306859, 'product-3.jpg', '2024-05-31', 270, 1, 1, 1, 'den', '3 kg', NULL, NULL),
(452, 'Nước hoa nữ', 7, 20269178, 12481817, 'product-2.jpg', '2024-05-31', 638, 0, 1, 4, 'trang', '3 kg', NULL, NULL),
(453, 'Mx97', 8, 25386456, 13320200, 'cat-4.jpg', '2024-05-31', 1123, 0, 1, 0, 'vang', '1 kg', NULL, NULL),
(454, 'G12', 3, 25617609, 13165394, 'product-9.jpg', '2024-05-31', 1827, 0, 0, 2, 'cam', '1 kg', NULL, NULL);
INSERT INTO `san_pham` (`id`, `ten`, `idnhasx`, `gia`, `giakm`, `hing`, `ngay`, `xem`, `hot`, `anhien`, `tinhchat`, `mausac`, `cannang`, `created_at`, `updated_at`) VALUES
(455, 'Nước hoa nam', 1, 28741144, 10169944, 'product-8.jpg', '2024-05-31', 473, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(456, 'Mx97', 7, 21017440, 10833544, 'product-3.jpg', '2024-05-31', 866, 0, 0, 4, 'vang', '1 kg', NULL, NULL),
(457, 'Iphone', 2, 23052156, 13138179, 'cat-3.jpg', '2024-05-31', 392, 1, 1, 2, 'trang', '1 kg', NULL, NULL),
(458, 'Kim cương', 5, 25772816, 11305343, 'product-3.jpg', '2024-05-31', 589, 1, 1, 4, 'cam', '1 kg', NULL, NULL),
(459, 'Iphone', 5, 23359111, 14087673, 'cat-4.jpg', '2024-05-31', 561, 1, 1, 1, 'cam', '3 kg', NULL, NULL),
(460, 'Camera', 1, 20892530, 14165761, 'product-8.jpg', '2024-05-31', 1754, 1, 0, 3, 'trang', '3 kg', NULL, NULL),
(461, 'Kim cương', 4, 20515688, 11551169, 'product-4.jpg', '2024-05-31', 637, 1, 0, 3, 'vang', '1 kg', NULL, NULL),
(462, 'Lenovo', 10, 26778287, 10515080, 'product-7.jpg', '2024-05-31', 1748, 0, 0, 1, 'den', '1 kg', NULL, NULL),
(463, 'Bạc', 4, 26243287, 14447297, 'product-1.jpg', '2024-05-31', 489, 0, 1, 3, 'den', '1 kg', NULL, NULL),
(464, 'Nước hoa nữ', 10, 27370132, 11788258, 'cat-1.jpg', '2024-05-31', 1477, 0, 0, 1, 'den', '1 kg', NULL, NULL),
(465, 'Vàng', 9, 29031791, 12785412, 'product-3.jpg', '2024-05-31', 237, 1, 0, 1, 'vang', '3 kg', NULL, NULL),
(466, 'Kim cương', 7, 24399201, 11129323, 'cat-2.jpg', '2024-05-31', 949, 0, 1, 1, 'vang', '3 kg', NULL, NULL),
(467, 'Nước hoa nam', 6, 23406802, 11452789, 'product-8.jpg', '2024-05-31', 1753, 1, 1, 2, 'cam', '2 kg', NULL, NULL),
(468, 'Mx97', 8, 24611670, 11432320, 'product-3.jpg', '2024-05-31', 665, 1, 1, 4, 'vang', '1 kg', NULL, NULL),
(469, 'Vàng', 5, 27321510, 11965470, 'cat-1.jpg', '2024-05-31', 901, 0, 1, 1, 'den', '2 kg', NULL, NULL),
(470, 'Banana', 2, 25056297, 14336101, 'product-2.jpg', '2024-05-31', 408, 0, 0, 2, 'vang', '2 kg', NULL, NULL),
(471, 'Banana', 5, 20329761, 14619293, 'product-8.jpg', '2024-05-31', 1760, 0, 1, 3, 'den', '1 kg', NULL, NULL),
(472, 'G12', 9, 23549183, 10095666, 'cat-3.jpg', '2024-05-31', 1815, 0, 1, 4, 'cam', '1 kg', NULL, NULL),
(473, 'G12', 3, 26634308, 12385492, 'product-2.jpg', '2024-05-31', 357, 0, 1, 1, 'trang', '3 kg', NULL, NULL),
(474, 'Lenovo', 1, 22600167, 10126487, 'cat-1.jpg', '2024-05-31', 1438, 1, 1, 3, 'cam', '3 kg', NULL, NULL),
(475, 'Iphone', 4, 20033541, 14687350, 'cat-2.jpg', '2024-05-31', 835, 0, 1, 1, 'trang', '3 kg', NULL, NULL),
(476, 'Apple', 3, 29902249, 11522623, 'product-2.jpg', '2024-05-31', 1947, 1, 0, 1, 'trang', '3 kg', NULL, NULL),
(477, 'Lenovo', 5, 27040820, 12503453, 'cat-1.jpg', '2024-05-31', 28, 0, 0, 1, 'den', '3 kg', NULL, NULL),
(478, 'Kim cương', 8, 23790219, 11674206, 'product-6.jpg', '2024-05-31', 1092, 0, 1, 3, 'den', '1 kg', NULL, NULL),
(479, 'Camera', 4, 29851679, 14479288, 'product-3.jpg', '2024-05-31', 576, 1, 1, 3, 'vang', '3 kg', NULL, NULL),
(480, 'G12', 5, 20359292, 13004768, 'cat-2.jpg', '2024-05-31', 1504, 0, 0, 2, 'cam', '2 kg', NULL, NULL),
(481, 'Camera', 2, 22295566, 13802871, 'product-4.jpg', '2024-05-31', 1563, 0, 1, 2, 'trang', '1 kg', NULL, NULL),
(482, 'Đầm phụ nữ', 4, 25389955, 11290857, 'product-6.jpg', '2024-05-31', 1134, 1, 0, 1, 'cam', '2 kg', NULL, NULL),
(483, 'Đầm phụ nữ', 5, 21422696, 12522647, 'product-6.jpg', '2024-05-31', 1633, 1, 1, 0, 'trang', '3 kg', NULL, NULL),
(484, 'Vàng', 1, 23684072, 13411175, 'cat-3.jpg', '2024-05-31', 1934, 1, 1, 3, 'trang', '2 kg', NULL, NULL),
(485, 'Asus', 9, 27891495, 14651979, 'product-5.jpg', '2024-05-31', 1881, 1, 1, 3, 'vang', '3 kg', NULL, NULL),
(486, 'Bạc', 4, 25988157, 14142908, 'cat-3.jpg', '2024-05-31', 243, 1, 1, 3, 'cam', '2 kg', NULL, NULL),
(487, 'Iphone', 5, 28355197, 10058683, 'cat-3.jpg', '2024-05-31', 1281, 0, 0, 4, 'vang', '2 kg', NULL, NULL),
(488, 'Apple', 7, 24808785, 10180235, 'product-3.jpg', '2024-05-31', 592, 0, 1, 0, 'vang', '1 kg', NULL, NULL),
(489, 'Đầm phụ nữ', 5, 24231740, 13078632, 'cat-3.jpg', '2024-05-31', 1042, 0, 0, 0, 'vang', '2 kg', NULL, NULL),
(490, 'Nước hoa nam', 4, 29256343, 11472278, 'product-8.jpg', '2024-05-31', 325, 0, 1, 2, 'trang', '2 kg', NULL, NULL),
(491, 'Nước hoa nữ', 10, 23158828, 13480335, 'cat-2.jpg', '2024-05-31', 468, 0, 1, 0, 'vang', '1 kg', NULL, NULL),
(492, 'Banana', 5, 22312039, 12174002, 'product-7.jpg', '2024-05-31', 1676, 0, 1, 2, 'den', '3 kg', NULL, NULL),
(493, 'Đầm phụ nữ', 4, 26772114, 11954799, 'product-5.jpg', '2024-05-31', 907, 1, 1, 0, 'trang', '1 kg', NULL, NULL),
(494, 'Banana', 3, 27624012, 12923226, 'product-9.jpg', '2024-05-31', 533, 1, 1, 1, 'den', '3 kg', NULL, NULL),
(495, 'Asus', 9, 20543581, 13914825, 'cat-3.jpg', '2024-05-31', 1865, 1, 1, 4, 'den', '3 kg', NULL, NULL),
(496, 'Bạc', 9, 29327557, 10552546, 'product-3.jpg', '2024-05-31', 1583, 0, 0, 3, 'trang', '2 kg', NULL, NULL),
(497, 'G12', 8, 26148434, 10593742, 'product-6.jpg', '2024-05-31', 351, 0, 0, 2, 'trang', '3 kg', NULL, NULL),
(498, 'Đầm phụ nữ', 8, 22479300, 11858800, 'cat-3.jpg', '2024-05-31', 659, 0, 0, 1, 'den', '1 kg', NULL, NULL),
(499, 'Iphone', 8, 25040172, 12110711, 'product-2.jpg', '2024-05-31', 505, 1, 1, 4, 'den', '2 kg', NULL, NULL),
(500, 'Kim cương', 3, 23673411, 14819382, 'product-6.jpg', '2024-05-31', 230, 1, 0, 1, 'cam', '3 kg', NULL, NULL),
(501, 'Banana', 9, 24602511, 11531770, 'product-8.jpg', '2024-05-31', 1781, 1, 1, 2, 'trang', '1 kg', NULL, NULL),
(502, 'Iphone', 9, 29272113, 14730296, 'product-1.jpg', '2024-05-31', 1966, 1, 1, 3, 'vang', '1 kg', NULL, NULL),
(503, 'Nước hoa nữ', 7, 29425483, 14985939, 'product-2.jpg', '2024-05-31', 650, 0, 0, 2, 'vang', '1 kg', NULL, NULL),
(504, 'Apple', 2, 28680621, 12760118, 'product-6.jpg', '2024-05-31', 1674, 1, 1, 2, 'vang', '1 kg', NULL, NULL),
(505, 'Lenovo', 4, 21669835, 14408767, 'product-5.jpg', '2024-05-31', 715, 0, 1, 1, 'trang', '2 kg', NULL, NULL),
(506, 'Đầm phụ nữ', 10, 26377321, 12546704, 'product-3.jpg', '2024-05-31', 149, 0, 1, 0, 'trang', '3 kg', NULL, NULL),
(507, 'Bạc', 10, 24599351, 13557324, 'cat-3.jpg', '2024-05-31', 168, 1, 0, 1, 'vang', '2 kg', NULL, NULL),
(508, 'Nước hoa nam', 1, 26466717, 11800601, 'product-8.jpg', '2024-05-31', 143, 0, 1, 0, 'trang', '3 kg', NULL, NULL),
(509, 'Asus', 1, 25607593, 12514751, 'cat-3.jpg', '2024-05-31', 1446, 1, 0, 0, 'vang', '2 kg', NULL, NULL),
(510, 'Camera', 3, 26803849, 13378598, 'cat-2.jpg', '2024-05-31', 59, 1, 1, 3, 'cam', '2 kg', NULL, NULL),
(511, 'Bạc', 9, 20516049, 11076069, 'cat-3.jpg', '2024-05-31', 595, 1, 1, 2, 'trang', '2 kg', NULL, NULL),
(512, 'Camera', 5, 26148332, 10040278, 'product-7.jpg', '2024-05-31', 772, 0, 1, 3, 'cam', '3 kg', NULL, NULL),
(513, 'Kim cương', 2, 28507238, 13831917, 'product-1.jpg', '2024-05-31', 515, 1, 0, 3, 'den', '2 kg', NULL, NULL),
(514, 'G12', 8, 27058241, 14777664, 'product-4.jpg', '2024-05-31', 553, 0, 0, 4, 'vang', '3 kg', NULL, NULL),
(515, 'G12', 3, 28606902, 10058550, 'cat-2.jpg', '2024-05-31', 1708, 1, 0, 0, 'cam', '2 kg', NULL, NULL),
(516, 'Banana', 6, 27366168, 13085157, 'product-7.jpg', '2024-05-31', 1454, 1, 1, 4, 'vang', '2 kg', NULL, NULL),
(517, 'Bạc', 8, 27976962, 10181535, 'product-7.jpg', '2024-05-31', 1538, 1, 0, 0, 'trang', '2 kg', NULL, NULL),
(518, 'G12', 3, 26323160, 10855010, 'product-5.jpg', '2024-05-31', 739, 0, 1, 4, 'den', '1 kg', NULL, NULL),
(519, 'Mx97', 5, 26741922, 12947835, 'product-2.jpg', '2024-05-31', 82, 0, 0, 2, 'cam', '2 kg', NULL, NULL),
(520, 'Đầm phụ nữ', 2, 21882625, 12155544, 'cat-3.jpg', '2024-05-31', 962, 0, 0, 1, 'vang', '2 kg', NULL, NULL),
(521, 'Nước hoa nam', 8, 25847156, 10081661, 'product-4.jpg', '2024-05-31', 749, 1, 0, 4, 'trang', '2 kg', NULL, NULL),
(522, 'Nước hoa nữ', 6, 23480532, 12398815, 'product-4.jpg', '2024-05-31', 1638, 1, 1, 3, 'trang', '1 kg', NULL, NULL),
(523, 'Lenovo', 10, 28062312, 13098425, 'product-3.jpg', '2024-05-31', 971, 1, 0, 2, 'cam', '3 kg', NULL, NULL),
(524, 'Kim cương', 3, 23475592, 13514240, 'product-9.jpg', '2024-05-31', 23, 1, 0, 2, 'trang', '2 kg', NULL, NULL),
(525, 'Bạc', 9, 29400890, 10501736, 'cat-1.jpg', '2024-05-31', 1921, 0, 1, 0, 'den', '3 kg', NULL, NULL),
(526, 'Mx97', 1, 25860039, 11063036, 'product-9.jpg', '2024-05-31', 38, 1, 0, 2, 'trang', '3 kg', NULL, NULL),
(527, 'G12', 5, 23016980, 13821381, 'cat-4.jpg', '2024-05-31', 523, 1, 1, 1, 'trang', '2 kg', NULL, NULL),
(528, 'Nước hoa nữ', 2, 21110979, 10756776, 'product-5.jpg', '2024-05-31', 978, 0, 1, 0, 'vang', '1 kg', NULL, NULL),
(529, 'Vàng', 4, 24744855, 12767085, 'product-7.jpg', '2024-05-31', 1497, 0, 0, 2, 'trang', '2 kg', NULL, NULL),
(530, 'Kim cương', 7, 27788387, 13398749, 'product-6.jpg', '2024-05-31', 993, 0, 0, 3, 'vang', '3 kg', NULL, NULL),
(531, 'G12', 6, 24753316, 13348414, 'product-4.jpg', '2024-05-31', 1890, 0, 0, 1, 'cam', '1 kg', NULL, NULL),
(532, 'Camera', 4, 21752443, 10036202, 'cat-2.jpg', '2024-05-31', 164, 1, 1, 4, 'vang', '2 kg', NULL, NULL),
(533, 'Vàng', 5, 23174980, 13736305, 'product-2.jpg', '2024-05-31', 1221, 1, 1, 4, 'vang', '1 kg', NULL, NULL),
(534, 'Mx97', 7, 23330261, 11721334, 'product-3.jpg', '2024-05-31', 152, 0, 0, 3, 'trang', '3 kg', NULL, NULL),
(535, 'Đầm phụ nữ', 4, 24024357, 14153437, 'cat-1.jpg', '2024-05-31', 1681, 1, 1, 1, 'cam', '1 kg', NULL, NULL),
(536, 'G12', 8, 28372137, 10492322, 'product-2.jpg', '2024-05-31', 565, 1, 1, 3, 'cam', '1 kg', NULL, NULL),
(537, 'Mx97', 8, 22310861, 12481153, 'cat-4.jpg', '2024-05-31', 1519, 0, 0, 4, 'cam', '3 kg', NULL, NULL),
(538, 'Nước hoa nữ', 5, 29785011, 14333431, 'product-6.jpg', '2024-05-31', 1068, 1, 1, 4, 'cam', '1 kg', NULL, NULL),
(539, 'G12', 4, 21311307, 10975524, 'cat-1.jpg', '2024-05-31', 926, 0, 1, 2, 'trang', '3 kg', NULL, NULL),
(540, 'Nước hoa nam', 5, 21035789, 13046573, 'product-5.jpg', '2024-05-31', 1354, 1, 1, 4, 'vang', '1 kg', NULL, NULL),
(541, 'Nước hoa nam', 6, 28184376, 14315819, 'cat-1.jpg', '2024-05-31', 1952, 1, 1, 0, 'trang', '2 kg', NULL, NULL),
(542, 'G12', 1, 22992766, 11580600, 'cat-2.jpg', '2024-05-31', 637, 1, 1, 2, 'trang', '2 kg', NULL, NULL),
(543, 'Đầm phụ nữ', 3, 27110978, 11346061, 'product-5.jpg', '2024-05-31', 1937, 0, 1, 2, 'den', '1 kg', NULL, NULL),
(544, 'G12', 1, 20682515, 11141475, 'product-9.jpg', '2024-05-31', 1579, 0, 1, 3, 'vang', '1 kg', NULL, NULL),
(545, 'Apple', 1, 25164001, 11365660, 'product-9.jpg', '2024-05-31', 757, 1, 0, 4, 'den', '1 kg', NULL, NULL),
(546, 'Bạc', 5, 27357742, 13214030, 'product-6.jpg', '2024-05-31', 1745, 1, 0, 1, 'trang', '3 kg', NULL, NULL),
(547, 'Asus', 3, 21752534, 10239737, 'product-3.jpg', '2024-05-31', 1037, 0, 0, 0, 'vang', '1 kg', NULL, NULL),
(548, 'Asus', 3, 25548450, 10996086, 'product-7.jpg', '2024-05-31', 1602, 0, 0, 1, 'vang', '1 kg', NULL, NULL),
(549, 'Asus', 5, 23083264, 13292990, 'cat-1.jpg', '2024-05-31', 1984, 1, 0, 0, 'vang', '3 kg', NULL, NULL),
(550, 'Vàng', 6, 29523252, 10401170, 'product-7.jpg', '2024-05-31', 824, 0, 0, 0, 'cam', '2 kg', NULL, NULL),
(551, 'Vàng', 1, 24128090, 14029638, 'product-1.jpg', '2024-05-31', 1369, 1, 0, 0, 'vang', '2 kg', NULL, NULL),
(552, 'Banana', 7, 28406307, 11145822, 'product-5.jpg', '2024-05-31', 609, 0, 0, 3, 'cam', '1 kg', NULL, NULL),
(553, 'Apple', 9, 24002682, 12388743, 'product-1.jpg', '2024-05-31', 376, 0, 1, 3, 'cam', '2 kg', NULL, NULL),
(554, 'Apple', 5, 22478088, 13703736, 'product-5.jpg', '2024-05-31', 123, 0, 0, 3, 'vang', '3 kg', NULL, NULL),
(555, 'Lenovo', 4, 20960219, 13152849, 'product-5.jpg', '2024-05-31', 112, 1, 0, 2, 'trang', '1 kg', NULL, NULL),
(556, 'Mx97', 8, 25014581, 13505259, 'product-9.jpg', '2024-05-31', 1127, 1, 1, 2, 'trang', '2 kg', NULL, NULL),
(557, 'Nước hoa nữ', 6, 21232985, 14497082, 'cat-2.jpg', '2024-05-31', 1415, 1, 0, 4, 'vang', '1 kg', NULL, NULL),
(558, 'G12', 4, 25916313, 13175275, 'product-7.jpg', '2024-05-31', 56, 1, 1, 0, 'den', '3 kg', NULL, NULL),
(559, 'Apple', 5, 28290354, 12937524, 'product-2.jpg', '2024-05-31', 1784, 0, 1, 0, 'cam', '2 kg', NULL, NULL),
(560, 'Asus', 1, 29073541, 10562541, 'product-9.jpg', '2024-05-31', 576, 0, 0, 1, 'cam', '3 kg', NULL, NULL),
(561, 'Bạc', 9, 29848408, 11233903, 'cat-2.jpg', '2024-05-31', 1702, 0, 1, 0, 'vang', '1 kg', NULL, NULL),
(562, 'Asus', 9, 23069170, 13284825, 'cat-3.jpg', '2024-05-31', 1196, 0, 1, 0, 'cam', '1 kg', NULL, NULL),
(563, 'Kim cương', 9, 23152533, 10769360, 'cat-3.jpg', '2024-05-31', 1443, 1, 1, 1, 'den', '1 kg', NULL, NULL),
(564, 'Asus', 9, 27825896, 11567403, 'product-7.jpg', '2024-05-31', 100, 1, 0, 4, 'den', '1 kg', NULL, NULL),
(565, 'Vàng', 2, 29268400, 13792972, 'product-9.jpg', '2024-05-31', 736, 1, 0, 0, 'trang', '1 kg', NULL, NULL),
(566, 'Lenovo', 6, 26364429, 10094960, 'product-6.jpg', '2024-05-31', 1471, 0, 1, 0, 'den', '2 kg', NULL, NULL),
(567, 'Đầm phụ nữ', 5, 20167208, 10052585, 'product-5.jpg', '2024-05-31', 896, 0, 0, 0, 'trang', '1 kg', NULL, NULL),
(568, 'Nước hoa nữ', 6, 25808305, 14123105, 'cat-2.jpg', '2024-05-31', 442, 0, 1, 0, 'cam', '3 kg', NULL, NULL),
(569, 'Apple', 8, 23468754, 13450588, 'product-2.jpg', '2024-05-31', 419, 0, 0, 1, 'cam', '2 kg', NULL, NULL),
(570, 'Banana', 10, 23719553, 13617680, 'product-3.jpg', '2024-05-31', 1393, 0, 0, 1, 'cam', '2 kg', NULL, NULL),
(571, 'Vàng', 6, 22021840, 13880408, 'product-8.jpg', '2024-05-31', 432, 0, 1, 1, 'vang', '2 kg', NULL, NULL),
(572, 'Đầm phụ nữ', 3, 23422876, 14604192, 'product-7.jpg', '2024-05-31', 1202, 0, 1, 3, 'den', '2 kg', NULL, NULL),
(573, 'Iphone', 6, 22628664, 12391604, 'product-4.jpg', '2024-05-31', 979, 1, 1, 3, 'trang', '3 kg', NULL, NULL),
(574, 'Asus', 9, 28655997, 14244893, 'product-9.jpg', '2024-05-31', 1269, 1, 0, 2, 'vang', '2 kg', NULL, NULL),
(575, 'Camera', 2, 21212507, 14558333, 'cat-1.jpg', '2024-05-31', 112, 0, 0, 3, 'den', '1 kg', NULL, NULL),
(576, 'Apple', 8, 20204671, 14018471, 'cat-2.jpg', '2024-05-31', 667, 1, 0, 0, 'trang', '3 kg', NULL, NULL),
(577, 'Camera', 10, 23147187, 11660329, 'cat-3.jpg', '2024-05-31', 768, 1, 1, 1, 'trang', '1 kg', NULL, NULL),
(578, 'Lenovo', 3, 22555096, 13149655, 'product-4.jpg', '2024-05-31', 746, 0, 0, 1, 'cam', '3 kg', NULL, NULL),
(579, 'Nước hoa nữ', 8, 23071681, 13118933, 'product-7.jpg', '2024-05-31', 602, 0, 0, 1, 'den', '2 kg', NULL, NULL),
(580, 'Kim cương', 6, 29284875, 14637409, 'product-7.jpg', '2024-05-31', 380, 1, 0, 4, 'vang', '3 kg', NULL, NULL),
(581, 'Vàng', 9, 25580467, 12324034, 'product-2.jpg', '2024-05-31', 1981, 1, 1, 3, 'cam', '1 kg', NULL, NULL),
(582, 'Bạc', 6, 23686394, 11910555, 'cat-3.jpg', '2024-05-31', 564, 1, 1, 4, 'cam', '1 kg', NULL, NULL),
(583, 'Vàng', 1, 23513741, 11359687, 'cat-2.jpg', '2024-05-31', 904, 0, 1, 3, 'trang', '1 kg', NULL, NULL),
(584, 'Asus', 5, 23037027, 11374447, 'cat-4.jpg', '2024-05-31', 325, 0, 0, 3, 'cam', '2 kg', NULL, NULL),
(585, 'Mx97', 7, 28390426, 14656655, 'product-2.jpg', '2024-05-31', 72, 0, 0, 0, 'trang', '1 kg', NULL, NULL),
(586, 'Lenovo', 8, 26535428, 14246900, 'product-4.jpg', '2024-05-31', 380, 0, 1, 3, 'vang', '1 kg', NULL, NULL),
(587, 'Kim cương', 5, 26393986, 14750852, 'product-5.jpg', '2024-05-31', 1996, 0, 0, 3, 'vang', '2 kg', NULL, NULL),
(588, 'Kim cương', 4, 24335410, 14677786, 'product-8.jpg', '2024-05-31', 158, 1, 1, 2, 'den', '1 kg', NULL, NULL),
(589, 'Lenovo', 1, 26027371, 13973379, 'product-3.jpg', '2024-05-31', 1908, 1, 0, 2, 'cam', '2 kg', NULL, NULL),
(590, 'Asus', 9, 28231136, 12199697, 'cat-1.jpg', '2024-05-31', 1118, 0, 1, 2, 'vang', '1 kg', NULL, NULL),
(591, 'Kim cương', 3, 26124845, 11723358, 'product-5.jpg', '2024-05-31', 1690, 0, 1, 4, 'trang', '1 kg', NULL, NULL),
(592, 'Mx97', 6, 28860065, 11355182, 'product-3.jpg', '2024-05-31', 945, 0, 0, 1, 'cam', '2 kg', NULL, NULL),
(593, 'Nước hoa nam', 6, 24236835, 10681514, 'product-3.jpg', '2024-05-31', 215, 1, 0, 2, 'vang', '1 kg', NULL, NULL),
(594, 'Camera', 7, 26167762, 10564305, 'cat-3.jpg', '2024-05-31', 1651, 0, 0, 0, 'cam', '1 kg', NULL, NULL),
(595, 'G12', 6, 23830261, 12861837, 'cat-4.jpg', '2024-05-31', 261, 1, 1, 4, 'cam', '3 kg', NULL, NULL),
(596, 'Nước hoa nữ', 3, 21096698, 13446662, 'product-4.jpg', '2024-05-31', 1229, 0, 0, 2, 'trang', '1 kg', NULL, NULL),
(597, 'G12', 2, 22605039, 13235467, 'product-8.jpg', '2024-05-31', 57, 0, 1, 1, 'den', '1 kg', NULL, NULL),
(598, 'Kim cương', 8, 25482189, 11030948, 'product-8.jpg', '2024-05-31', 788, 1, 1, 2, 'trang', '3 kg', NULL, NULL),
(599, 'Asus', 6, 23451969, 11721619, 'product-5.jpg', '2024-05-31', 1630, 1, 0, 3, 'den', '3 kg', NULL, NULL),
(600, 'Lenovo', 8, 21279295, 12356229, 'cat-4.jpg', '2024-05-31', 1223, 0, 0, 4, 'den', '3 kg', NULL, NULL),
(601, 'Lenovo', 4, 24797442, 13768985, 'product-9.jpg', '2024-05-31', 1911, 1, 1, 2, 'trang', '2 kg', NULL, NULL),
(602, 'Lenovo', 8, 27286312, 11362008, 'cat-2.jpg', '2024-05-31', 577, 1, 0, 2, 'cam', '3 kg', NULL, NULL),
(603, 'Kim cương', 7, 28737522, 11127206, 'product-1.jpg', '2024-05-31', 1813, 0, 0, 0, 'vang', '2 kg', NULL, NULL),
(604, 'G12', 3, 24713985, 10100274, 'product-1.jpg', '2024-05-31', 1636, 0, 0, 3, 'trang', '2 kg', NULL, NULL),
(605, 'G12', 3, 28007985, 13004064, 'product-1.jpg', '2024-05-31', 1585, 0, 1, 4, 'trang', '1 kg', NULL, NULL),
(606, 'Mx97', 3, 29945604, 11785975, 'product-4.jpg', '2024-05-31', 1447, 0, 0, 2, 'cam', '3 kg', NULL, NULL),
(607, 'Vàng', 5, 27530059, 14462695, 'cat-2.jpg', '2024-05-31', 1109, 0, 1, 4, 'trang', '3 kg', NULL, NULL),
(608, 'G12', 5, 28317969, 13485984, 'product-8.jpg', '2024-05-31', 83, 1, 1, 4, 'trang', '1 kg', NULL, NULL),
(609, 'Iphone', 6, 28088886, 12221534, 'cat-2.jpg', '2024-05-31', 730, 0, 0, 0, 'cam', '1 kg', NULL, NULL),
(610, 'Bạc', 9, 26371981, 13810054, 'product-8.jpg', '2024-05-31', 1570, 0, 0, 3, 'cam', '1 kg', NULL, NULL),
(611, 'Nước hoa nữ', 3, 28471538, 11911331, 'product-1.jpg', '2024-05-31', 1156, 0, 1, 2, 'den', '2 kg', NULL, NULL),
(612, 'Lenovo', 6, 20985575, 13578155, 'cat-1.jpg', '2024-05-31', 626, 1, 1, 2, 'den', '2 kg', NULL, NULL),
(613, 'Asus', 7, 25275716, 11784356, 'cat-4.jpg', '2024-05-31', 1645, 0, 1, 4, 'cam', '2 kg', NULL, NULL),
(614, 'Vàng', 2, 20690412, 12560770, 'cat-2.jpg', '2024-05-31', 1642, 1, 1, 2, 'vang', '1 kg', NULL, NULL),
(615, 'Bạc', 6, 20858513, 13652301, 'product-9.jpg', '2024-05-31', 184, 0, 1, 4, 'den', '3 kg', NULL, NULL),
(616, 'Vàng', 1, 22377545, 12271816, 'product-7.jpg', '2024-05-31', 751, 0, 1, 3, 'vang', '3 kg', NULL, NULL),
(617, 'G12', 9, 22092618, 13205903, 'product-5.jpg', '2024-05-31', 42, 0, 1, 0, 'cam', '3 kg', NULL, NULL),
(618, 'Đầm phụ nữ', 10, 21178725, 12055860, 'product-4.jpg', '2024-05-31', 940, 1, 0, 0, 'den', '3 kg', NULL, NULL),
(619, 'Asus', 6, 26512768, 10499672, 'cat-1.jpg', '2024-05-31', 1762, 0, 1, 3, 'den', '1 kg', NULL, NULL),
(620, 'Bạc', 9, 25728747, 14481210, 'product-3.jpg', '2024-05-31', 813, 0, 0, 3, 'vang', '2 kg', NULL, NULL),
(621, 'Vàng', 3, 22027864, 10432596, 'cat-3.jpg', '2024-05-31', 1152, 0, 1, 0, 'cam', '3 kg', NULL, NULL),
(622, 'Nước hoa nam', 1, 25869982, 11679722, 'product-4.jpg', '2024-05-31', 1235, 1, 0, 0, 'cam', '3 kg', NULL, NULL),
(623, 'Bạc', 4, 22199724, 10566997, 'product-2.jpg', '2024-05-31', 1117, 0, 0, 0, 'vang', '3 kg', NULL, NULL),
(624, 'Bạc', 2, 20495162, 13204029, 'product-9.jpg', '2024-05-31', 633, 0, 0, 2, 'den', '3 kg', NULL, NULL),
(625, 'Bạc', 9, 29496391, 13441496, 'cat-3.jpg', '2024-05-31', 1740, 0, 1, 3, 'den', '2 kg', NULL, NULL),
(626, 'Bạc', 5, 21426296, 10070432, 'cat-1.jpg', '2024-05-31', 1798, 0, 1, 2, 'cam', '1 kg', NULL, NULL),
(627, 'G12', 7, 28135834, 14714871, 'product-8.jpg', '2024-05-31', 791, 0, 1, 4, 'den', '3 kg', NULL, NULL),
(628, 'Đầm phụ nữ', 10, 24034381, 10459685, 'cat-1.jpg', '2024-05-31', 1887, 0, 0, 4, 'trang', '1 kg', NULL, NULL),
(629, 'Mx97', 10, 20107895, 10619049, 'product-1.jpg', '2024-05-31', 345, 0, 1, 2, 'vang', '2 kg', NULL, NULL),
(630, 'Camera', 7, 27564454, 11010212, 'cat-2.jpg', '2024-05-31', 1935, 1, 1, 0, 'trang', '3 kg', NULL, NULL),
(631, 'Bạc', 5, 24576563, 14521543, 'cat-2.jpg', '2024-05-31', 1538, 0, 0, 1, 'trang', '3 kg', NULL, NULL),
(632, 'Iphone', 8, 25310607, 10375173, 'cat-3.jpg', '2024-05-31', 644, 1, 0, 3, 'den', '3 kg', NULL, NULL),
(633, 'Apple', 5, 22166178, 11611884, 'product-5.jpg', '2024-05-31', 1609, 0, 0, 2, 'vang', '1 kg', NULL, NULL),
(634, 'Bạc', 2, 23389788, 13217684, 'product-5.jpg', '2024-05-31', 626, 0, 1, 0, 'vang', '1 kg', NULL, NULL),
(635, 'Lenovo', 8, 22259882, 12027082, 'product-4.jpg', '2024-05-31', 1977, 0, 0, 1, 'cam', '1 kg', NULL, NULL),
(636, 'Lenovo', 8, 24737330, 10470171, 'cat-1.jpg', '2024-05-31', 34, 1, 1, 3, 'vang', '2 kg', NULL, NULL),
(637, 'Asus', 5, 27253150, 14221994, 'product-8.jpg', '2024-05-31', 1532, 1, 0, 0, 'trang', '3 kg', NULL, NULL),
(638, 'Camera', 7, 26646054, 13447181, 'product-8.jpg', '2024-05-31', 935, 0, 0, 2, 'den', '2 kg', NULL, NULL),
(639, 'Iphone', 2, 21769766, 14850969, 'product-5.jpg', '2024-05-31', 65, 0, 1, 1, 'den', '3 kg', NULL, NULL),
(640, 'Asus', 2, 28246904, 10036457, 'product-6.jpg', '2024-05-31', 767, 0, 1, 1, 'trang', '1 kg', NULL, NULL),
(641, 'Apple', 7, 22116957, 14143030, 'product-5.jpg', '2024-05-31', 101, 0, 1, 3, 'trang', '3 kg', NULL, NULL),
(642, 'Apple', 4, 26619442, 11832345, 'product-8.jpg', '2024-05-31', 0, 0, 1, 1, 'den', '2 kg', NULL, NULL),
(643, 'Nước hoa nam', 4, 27500482, 12390382, 'product-7.jpg', '2024-05-31', 418, 0, 0, 2, 'den', '2 kg', NULL, NULL),
(644, 'Nước hoa nữ', 5, 27271421, 10822034, 'product-8.jpg', '2024-05-31', 1421, 1, 1, 0, 'trang', '3 kg', NULL, NULL),
(645, 'Mx97', 7, 29880074, 13725366, 'product-2.jpg', '2024-05-31', 1468, 1, 1, 0, 'den', '2 kg', NULL, NULL),
(646, 'Nước hoa nữ', 10, 28383323, 14710528, 'cat-2.jpg', '2024-05-31', 1602, 0, 1, 0, 'cam', '2 kg', NULL, NULL),
(647, 'G12', 2, 20881217, 12100740, 'product-5.jpg', '2024-05-31', 1888, 0, 0, 4, 'den', '3 kg', NULL, NULL),
(648, 'Bạc', 10, 28556478, 11607122, 'cat-4.jpg', '2024-05-31', 538, 0, 0, 3, 'trang', '2 kg', NULL, NULL),
(649, 'Lenovo', 7, 27033110, 10416046, 'product-1.jpg', '2024-05-31', 430, 1, 1, 4, 'trang', '1 kg', NULL, NULL),
(650, 'G12', 10, 23389340, 11448969, 'product-3.jpg', '2024-05-31', 1371, 1, 1, 0, 'trang', '2 kg', NULL, NULL),
(651, 'Nước hoa nữ', 10, 21957738, 13904747, 'product-5.jpg', '2024-05-31', 1275, 0, 0, 3, 'den', '3 kg', NULL, NULL),
(652, 'Lenovo', 2, 28176225, 12357490, 'product-5.jpg', '2024-05-31', 1300, 0, 0, 0, 'trang', '1 kg', NULL, NULL),
(653, 'Apple', 6, 28928741, 10240886, 'product-6.jpg', '2024-05-31', 620, 1, 0, 4, 'den', '1 kg', NULL, NULL),
(654, 'Mx97', 1, 26561806, 10821501, 'product-9.jpg', '2024-05-31', 742, 0, 1, 0, 'trang', '1 kg', NULL, NULL),
(655, 'Bạc', 8, 22291404, 10946520, 'cat-2.jpg', '2024-05-31', 900, 1, 1, 1, 'den', '3 kg', NULL, NULL),
(656, 'Vàng', 2, 29115754, 12931283, 'product-6.jpg', '2024-05-31', 1106, 0, 1, 2, 'cam', '2 kg', NULL, NULL),
(657, 'Camera', 9, 22346125, 14698075, 'cat-3.jpg', '2024-05-31', 1515, 1, 1, 2, 'den', '3 kg', NULL, NULL),
(658, 'Asus', 3, 21481256, 13630322, 'product-1.jpg', '2024-05-31', 694, 0, 1, 4, 'trang', '3 kg', NULL, NULL),
(659, 'Lenovo', 8, 27747473, 12618018, 'product-7.jpg', '2024-05-31', 97, 0, 0, 0, 'vang', '2 kg', NULL, NULL),
(660, 'Lenovo', 8, 24531981, 12121933, 'product-4.jpg', '2024-05-31', 201, 0, 1, 3, 'trang', '3 kg', NULL, NULL),
(661, 'G12', 9, 21773359, 13023432, 'cat-3.jpg', '2024-05-31', 254, 1, 1, 3, 'cam', '3 kg', NULL, NULL),
(662, 'Kim cương', 2, 28836405, 11709197, 'cat-2.jpg', '2024-05-31', 1412, 0, 1, 1, 'trang', '1 kg', NULL, NULL),
(663, 'Nước hoa nam', 6, 23567554, 11007672, 'cat-4.jpg', '2024-05-31', 219, 1, 0, 2, 'den', '3 kg', NULL, NULL),
(664, 'Nước hoa nữ', 6, 28750810, 12166099, 'product-2.jpg', '2024-05-31', 1520, 1, 0, 4, 'cam', '2 kg', NULL, NULL),
(665, 'Vàng', 9, 26647436, 14586076, 'product-9.jpg', '2024-05-31', 543, 1, 1, 0, 'den', '3 kg', NULL, NULL),
(666, 'G12', 8, 20011483, 10826983, 'product-5.jpg', '2024-05-31', 233, 1, 1, 0, 'den', '2 kg', NULL, NULL),
(667, 'Mx97', 7, 23255387, 13155528, 'cat-4.jpg', '2024-05-31', 1753, 1, 0, 1, 'den', '1 kg', NULL, NULL),
(668, 'Kim cương', 3, 29061753, 14256487, 'product-2.jpg', '2024-05-31', 790, 1, 1, 4, 'vang', '3 kg', NULL, NULL),
(669, 'Bạc', 4, 27764543, 12525933, 'product-6.jpg', '2024-05-31', 843, 1, 1, 1, 'trang', '2 kg', NULL, NULL),
(670, 'Banana', 1, 28839957, 11257914, 'cat-1.jpg', '2024-05-31', 568, 0, 0, 4, 'vang', '1 kg', NULL, NULL),
(671, 'Apple', 10, 26928456, 14233611, 'product-2.jpg', '2024-05-31', 1298, 0, 1, 4, 'vang', '2 kg', NULL, NULL),
(672, 'Camera', 2, 25332031, 11416059, 'cat-1.jpg', '2024-05-31', 105, 0, 1, 4, 'trang', '2 kg', NULL, NULL),
(673, 'Vàng', 5, 25146750, 13384218, 'cat-1.jpg', '2024-05-31', 747, 1, 1, 4, 'trang', '2 kg', NULL, NULL),
(674, 'Mx97', 6, 27517245, 11374314, 'product-8.jpg', '2024-05-31', 1346, 0, 1, 0, 'vang', '1 kg', NULL, NULL),
(675, 'Iphone', 9, 22251401, 12484896, 'product-4.jpg', '2024-05-31', 1119, 1, 1, 1, 'den', '2 kg', NULL, NULL),
(676, 'Kim cương', 1, 21389918, 11462826, 'product-5.jpg', '2024-05-31', 1372, 1, 1, 2, 'cam', '2 kg', NULL, NULL),
(677, 'G12', 8, 22163519, 11725889, 'product-3.jpg', '2024-05-31', 1875, 0, 0, 2, 'vang', '2 kg', NULL, NULL),
(678, 'Mx97', 1, 28368790, 10806737, 'product-7.jpg', '2024-05-31', 1587, 1, 1, 0, 'vang', '2 kg', NULL, NULL),
(679, 'Bạc', 10, 28567569, 13272142, 'product-6.jpg', '2024-05-31', 806, 0, 1, 1, 'vang', '2 kg', NULL, NULL),
(680, 'G12', 8, 27716154, 13303833, 'cat-4.jpg', '2024-05-31', 660, 1, 1, 2, 'vang', '1 kg', NULL, NULL),
(681, 'Apple', 10, 27928448, 11521715, 'product-7.jpg', '2024-05-31', 1871, 1, 0, 0, 'cam', '2 kg', NULL, NULL),
(682, 'Iphone', 5, 29581902, 13515944, 'product-9.jpg', '2024-05-31', 1472, 0, 1, 2, 'trang', '3 kg', NULL, NULL),
(683, 'Banana', 2, 28467505, 13853463, 'product-1.jpg', '2024-05-31', 1183, 0, 1, 2, 'vang', '2 kg', NULL, NULL),
(684, 'Apple', 5, 28404529, 14747199, 'cat-4.jpg', '2024-05-31', 412, 1, 1, 4, 'cam', '3 kg', NULL, NULL),
(685, 'Mx97', 6, 28661558, 12730327, 'product-2.jpg', '2024-05-31', 78, 1, 0, 1, 'den', '3 kg', NULL, NULL),
(686, 'Kim cương', 1, 23606138, 12762301, 'product-7.jpg', '2024-05-31', 7, 0, 1, 0, 'den', '3 kg', NULL, NULL),
(687, 'Kim cương', 10, 23643530, 10839334, 'product-9.jpg', '2024-05-31', 837, 1, 0, 3, 'cam', '3 kg', NULL, NULL),
(688, 'Lenovo', 10, 29451266, 13776395, 'product-4.jpg', '2024-05-31', 1389, 0, 0, 0, 'vang', '1 kg', NULL, NULL),
(689, 'Kim cương', 2, 22705150, 11172626, 'product-8.jpg', '2024-05-31', 373, 0, 0, 4, 'trang', '2 kg', NULL, NULL),
(690, 'Iphone', 5, 29230559, 12130638, 'product-9.jpg', '2024-05-31', 225, 0, 1, 3, 'den', '1 kg', NULL, NULL),
(691, 'Nước hoa nữ', 1, 28849566, 10901747, 'product-9.jpg', '2024-05-31', 1732, 1, 0, 4, 'vang', '3 kg', NULL, NULL),
(692, 'Apple', 6, 27249202, 11815233, 'product-7.jpg', '2024-05-31', 1419, 0, 0, 1, 'den', '2 kg', NULL, NULL),
(693, 'Apple', 8, 21117755, 13407250, 'cat-4.jpg', '2024-05-31', 1124, 0, 1, 1, 'trang', '2 kg', NULL, NULL),
(694, 'G12', 8, 26704563, 10999288, 'product-1.jpg', '2024-05-31', 925, 1, 0, 2, 'cam', '3 kg', NULL, NULL),
(695, 'Banana', 5, 23533518, 13218997, 'product-1.jpg', '2024-05-31', 1928, 0, 0, 2, 'cam', '1 kg', NULL, NULL),
(696, 'Bạc', 3, 25717256, 11410123, 'cat-3.jpg', '2024-05-31', 0, 0, 1, 3, 'trang', '3 kg', NULL, NULL),
(697, 'Camera', 7, 27216484, 10611998, 'product-2.jpg', '2024-05-31', 1899, 0, 0, 3, 'den', '1 kg', NULL, NULL),
(698, 'Asus', 7, 20509720, 14092708, 'product-7.jpg', '2024-05-31', 453, 0, 1, 2, 'cam', '1 kg', NULL, NULL),
(699, 'Vàng', 8, 29746501, 10066598, 'product-6.jpg', '2024-05-31', 85, 0, 1, 3, 'den', '3 kg', NULL, NULL),
(700, 'Banana', 2, 24136230, 13308061, 'product-2.jpg', '2024-05-31', 1864, 0, 0, 1, 'den', '2 kg', NULL, NULL),
(701, 'Lenovo', 5, 28263672, 14405172, 'product-3.jpg', '2024-05-31', 1796, 1, 0, 3, 'cam', '3 kg', NULL, NULL),
(702, 'Asus', 5, 21757897, 13235341, 'product-9.jpg', '2024-05-31', 221, 1, 1, 3, 'den', '2 kg', NULL, NULL),
(703, 'Kim cương', 7, 24692724, 12992419, 'product-2.jpg', '2024-05-31', 1724, 1, 1, 3, 'cam', '1 kg', NULL, NULL),
(704, 'Vàng', 10, 25378833, 10534488, 'cat-3.jpg', '2024-05-31', 1037, 1, 0, 3, 'cam', '1 kg', NULL, NULL),
(705, 'Nước hoa nam', 1, 27270229, 10533216, 'product-1.jpg', '2024-05-31', 151, 1, 0, 2, 'den', '2 kg', NULL, NULL),
(706, 'Iphone', 7, 23701008, 14180514, 'product-9.jpg', '2024-05-31', 266, 1, 0, 3, 'vang', '1 kg', NULL, NULL),
(707, 'Camera', 9, 22241816, 10972975, 'cat-1.jpg', '2024-05-31', 525, 1, 1, 4, 'vang', '3 kg', NULL, NULL),
(708, 'G12', 5, 24939113, 12870882, 'cat-3.jpg', '2024-05-31', 1207, 0, 0, 0, 'vang', '1 kg', NULL, NULL),
(709, 'G12', 4, 27210150, 11937853, 'product-5.jpg', '2024-05-31', 457, 1, 0, 2, 'cam', '1 kg', NULL, NULL),
(710, 'Nước hoa nữ', 4, 28366926, 14150513, 'product-3.jpg', '2024-05-31', 147, 0, 0, 0, 'den', '2 kg', NULL, NULL),
(711, 'Bạc', 9, 22720632, 10387155, 'product-1.jpg', '2024-05-31', 416, 0, 0, 2, 'vang', '3 kg', NULL, NULL),
(712, 'Bạc', 6, 28782401, 13079571, 'product-1.jpg', '2024-05-31', 1413, 1, 0, 0, 'den', '1 kg', NULL, NULL),
(713, 'Vàng', 7, 28962489, 12370287, 'cat-4.jpg', '2024-05-31', 1883, 0, 0, 2, 'den', '3 kg', NULL, NULL),
(714, 'Kim cương', 7, 23914081, 11177284, 'product-6.jpg', '2024-05-31', 1764, 1, 0, 2, 'den', '3 kg', NULL, NULL),
(715, 'Đầm phụ nữ', 8, 27646366, 12258237, 'product-4.jpg', '2024-05-31', 882, 0, 1, 1, 'cam', '2 kg', NULL, NULL),
(716, 'Mx97', 6, 21949657, 12477051, 'product-5.jpg', '2024-05-31', 1408, 1, 1, 4, 'vang', '1 kg', NULL, NULL),
(717, 'Mx97', 2, 24038352, 14333357, 'product-6.jpg', '2024-05-31', 13, 0, 1, 0, 'vang', '2 kg', NULL, NULL),
(718, 'Lenovo', 5, 21789240, 14544665, 'product-8.jpg', '2024-05-31', 1034, 1, 1, 0, 'trang', '2 kg', NULL, NULL),
(719, 'Nước hoa nam', 8, 22650125, 10990096, 'product-8.jpg', '2024-05-31', 1239, 0, 0, 4, 'trang', '1 kg', NULL, NULL),
(720, 'Asus', 3, 21282424, 11300848, 'cat-2.jpg', '2024-05-31', 1528, 0, 0, 1, 'trang', '3 kg', NULL, NULL),
(721, 'Nước hoa nữ', 3, 28113854, 10403115, 'cat-4.jpg', '2024-05-31', 207, 1, 1, 2, 'vang', '2 kg', NULL, NULL),
(722, 'Đầm phụ nữ', 2, 22989518, 11335276, 'cat-2.jpg', '2024-05-31', 1377, 1, 1, 3, 'cam', '3 kg', NULL, NULL),
(723, 'Asus', 7, 25707529, 11352103, 'cat-1.jpg', '2024-05-31', 685, 0, 0, 0, 'den', '1 kg', NULL, NULL),
(724, 'Vàng', 9, 28787226, 13265130, 'product-2.jpg', '2024-05-31', 1223, 0, 0, 0, 'den', '2 kg', NULL, NULL),
(725, 'Đầm phụ nữ', 3, 27222201, 14583564, 'cat-3.jpg', '2024-05-31', 807, 1, 1, 1, 'den', '2 kg', NULL, NULL),
(726, 'Banana', 4, 20050300, 11401161, 'product-9.jpg', '2024-05-31', 187, 1, 1, 1, 'vang', '3 kg', NULL, NULL),
(727, 'Đầm phụ nữ', 1, 28772697, 12911681, 'product-9.jpg', '2024-05-31', 1673, 1, 1, 1, 'den', '2 kg', NULL, NULL),
(728, 'Nước hoa nữ', 1, 23798988, 13326426, 'product-2.jpg', '2024-05-31', 175, 1, 0, 0, 'den', '2 kg', NULL, NULL),
(729, 'Nước hoa nữ', 10, 26747490, 14111409, 'cat-4.jpg', '2024-05-31', 1419, 1, 1, 4, 'vang', '2 kg', NULL, NULL),
(730, 'Mx97', 3, 23245973, 10499953, 'product-3.jpg', '2024-05-31', 1228, 1, 0, 2, 'den', '2 kg', NULL, NULL),
(731, 'Camera', 10, 25572739, 13048964, 'product-4.jpg', '2024-05-31', 1916, 1, 0, 0, 'den', '3 kg', NULL, NULL),
(732, 'Mx97', 3, 26336932, 11296004, 'product-6.jpg', '2024-05-31', 921, 1, 1, 2, 'trang', '1 kg', NULL, NULL),
(733, 'Lenovo', 4, 24500550, 10978326, 'product-9.jpg', '2024-05-31', 1868, 0, 1, 1, 'vang', '2 kg', NULL, NULL),
(734, 'Lenovo', 3, 25377183, 12284592, 'cat-2.jpg', '2024-05-31', 1048, 1, 0, 0, 'den', '1 kg', NULL, NULL),
(735, 'Asus', 9, 29083013, 11827034, 'product-5.jpg', '2024-05-31', 79, 0, 0, 4, 'den', '1 kg', NULL, NULL),
(736, 'G12', 3, 25216300, 12494357, 'cat-4.jpg', '2024-05-31', 762, 0, 0, 4, 'vang', '2 kg', NULL, NULL),
(737, 'Apple', 8, 23455580, 14886041, 'product-4.jpg', '2024-05-31', 780, 0, 1, 4, 'cam', '2 kg', NULL, NULL),
(738, 'Vàng', 8, 21705273, 10155325, 'cat-4.jpg', '2024-05-31', 1023, 1, 1, 3, 'vang', '3 kg', NULL, NULL),
(739, 'Banana', 1, 25317253, 13356023, 'product-4.jpg', '2024-05-31', 742, 1, 1, 2, 'vang', '1 kg', NULL, NULL),
(740, 'Asus', 2, 25481216, 14675878, 'product-7.jpg', '2024-05-31', 409, 0, 0, 0, 'den', '3 kg', NULL, NULL),
(741, 'Kim cương', 9, 27071794, 13082216, 'product-1.jpg', '2024-05-31', 951, 1, 1, 1, 'vang', '1 kg', NULL, NULL),
(742, 'Nước hoa nữ', 2, 22066374, 11937885, 'product-4.jpg', '2024-05-31', 529, 0, 0, 4, 'trang', '2 kg', NULL, NULL),
(743, 'Nước hoa nam', 7, 28839944, 12806164, 'product-6.jpg', '2024-05-31', 1195, 0, 1, 2, 'den', '1 kg', NULL, NULL),
(744, 'Apple', 2, 25357989, 10105490, 'cat-1.jpg', '2024-05-31', 1432, 1, 0, 0, 'cam', '1 kg', NULL, NULL),
(745, 'Iphone', 9, 27798060, 14871490, 'product-1.jpg', '2024-05-31', 652, 0, 0, 1, 'trang', '1 kg', NULL, NULL),
(746, 'Apple', 1, 27823261, 12647338, 'cat-2.jpg', '2024-05-31', 178, 0, 1, 2, 'trang', '2 kg', NULL, NULL),
(747, 'Bạc', 7, 22452902, 14304030, 'product-3.jpg', '2024-05-31', 57, 1, 0, 2, 'cam', '1 kg', NULL, NULL),
(748, 'Mx97', 10, 22460511, 14804096, 'cat-3.jpg', '2024-05-31', 942, 1, 1, 4, 'den', '3 kg', NULL, NULL),
(749, 'Lenovo', 7, 20263004, 13081776, 'cat-2.jpg', '2024-05-31', 545, 1, 1, 0, 'trang', '3 kg', NULL, NULL),
(750, 'Đầm phụ nữ', 6, 27682183, 12078625, 'cat-4.jpg', '2024-05-31', 1577, 1, 0, 3, 'cam', '1 kg', NULL, NULL),
(751, 'Iphone', 10, 28961169, 11695430, 'cat-2.jpg', '2024-05-31', 1841, 0, 1, 1, 'den', '2 kg', NULL, NULL),
(752, 'Banana', 1, 22498136, 14846635, 'cat-4.jpg', '2024-05-31', 146, 0, 1, 2, 'den', '1 kg', NULL, NULL),
(753, 'Apple', 8, 28575705, 12989987, 'cat-4.jpg', '2024-05-31', 1980, 0, 1, 4, 'cam', '1 kg', NULL, NULL),
(754, 'G12', 5, 26315394, 13108958, 'product-7.jpg', '2024-05-31', 1629, 1, 1, 2, 'vang', '1 kg', NULL, NULL),
(755, 'Nước hoa nữ', 1, 29551579, 12580928, 'cat-2.jpg', '2024-05-31', 469, 0, 0, 0, 'vang', '1 kg', NULL, NULL),
(756, 'Nước hoa nữ', 7, 27724184, 14635539, 'product-7.jpg', '2024-05-31', 1195, 1, 1, 4, 'vang', '1 kg', NULL, NULL),
(757, 'Đầm phụ nữ', 5, 28545689, 13523369, 'product-6.jpg', '2024-05-31', 1856, 0, 1, 2, 'trang', '3 kg', NULL, NULL),
(758, 'Vàng', 6, 22620278, 14020851, 'product-5.jpg', '2024-05-31', 331, 0, 0, 4, 'vang', '1 kg', NULL, NULL),
(759, 'Vàng', 4, 25753108, 11535177, 'cat-4.jpg', '2024-05-31', 1685, 1, 0, 1, 'trang', '1 kg', NULL, NULL),
(760, 'Vàng', 10, 27393938, 12359682, 'product-9.jpg', '2024-05-31', 1519, 0, 0, 4, 'trang', '3 kg', NULL, NULL),
(761, 'Lenovo', 10, 20857683, 11847264, 'cat-4.jpg', '2024-05-31', 5, 1, 1, 1, 'vang', '1 kg', NULL, NULL),
(762, 'Đầm phụ nữ', 1, 25215844, 11939707, 'cat-3.jpg', '2024-05-31', 1383, 0, 1, 1, 'cam', '3 kg', NULL, NULL),
(763, 'Nước hoa nữ', 4, 23785481, 14250138, 'cat-1.jpg', '2024-05-31', 1132, 0, 1, 1, 'cam', '3 kg', NULL, NULL),
(764, 'G12', 4, 26292026, 14771786, 'product-2.jpg', '2024-05-31', 728, 1, 0, 1, 'cam', '2 kg', NULL, NULL),
(765, 'Camera', 8, 28415098, 13442199, 'product-7.jpg', '2024-05-31', 1201, 0, 1, 0, 'cam', '1 kg', NULL, NULL),
(766, 'Nước hoa nam', 3, 26434249, 11022128, 'product-4.jpg', '2024-05-31', 504, 1, 0, 3, 'cam', '3 kg', NULL, NULL),
(767, 'Mx97', 8, 22392524, 11744713, 'cat-4.jpg', '2024-05-31', 415, 1, 0, 3, 'vang', '2 kg', NULL, NULL),
(768, 'Iphone', 8, 23177205, 13653349, 'product-1.jpg', '2024-05-31', 1333, 1, 0, 0, 'trang', '1 kg', NULL, NULL),
(769, 'Iphone', 6, 27962636, 10415177, 'product-9.jpg', '2024-05-31', 879, 0, 0, 2, 'den', '3 kg', NULL, NULL),
(770, 'G12', 1, 26098804, 14695093, 'product-2.jpg', '2024-05-31', 882, 0, 1, 2, 'den', '3 kg', NULL, NULL),
(771, 'Banana', 10, 28882038, 12537113, 'product-4.jpg', '2024-05-31', 1759, 0, 1, 3, 'vang', '3 kg', NULL, NULL),
(772, 'Camera', 7, 29123201, 14568565, 'cat-1.jpg', '2024-05-31', 1075, 1, 1, 0, 'vang', '2 kg', NULL, NULL),
(773, 'Banana', 8, 26979484, 13829054, 'cat-1.jpg', '2024-05-31', 1907, 0, 1, 3, 'den', '3 kg', NULL, NULL),
(774, 'Nước hoa nữ', 8, 23860090, 11529078, 'product-3.jpg', '2024-05-31', 826, 0, 0, 3, 'vang', '2 kg', NULL, NULL),
(775, 'Bạc', 4, 25938319, 14154506, 'product-7.jpg', '2024-05-31', 798, 1, 1, 4, 'trang', '1 kg', NULL, NULL),
(776, 'Lenovo', 1, 23645364, 14536175, 'cat-3.jpg', '2024-05-31', 1342, 0, 0, 2, 'cam', '3 kg', NULL, NULL),
(777, 'Apple', 10, 29559967, 14223011, 'product-7.jpg', '2024-05-31', 855, 0, 0, 2, 'vang', '3 kg', NULL, NULL),
(778, 'Apple', 2, 22028279, 14801071, 'cat-4.jpg', '2024-05-31', 1569, 0, 1, 1, 'vang', '1 kg', NULL, NULL),
(779, 'Mx97', 1, 28895263, 11539931, 'product-6.jpg', '2024-05-31', 1348, 0, 0, 1, 'cam', '2 kg', NULL, NULL),
(780, 'Nước hoa nam', 2, 27799072, 10871834, 'cat-1.jpg', '2024-05-31', 11, 0, 0, 2, 'vang', '2 kg', NULL, NULL),
(781, 'Iphone', 8, 20682992, 11910524, 'product-4.jpg', '2024-05-31', 79, 1, 1, 1, 'den', '3 kg', NULL, NULL),
(782, 'Vàng', 9, 23565281, 13475497, 'product-6.jpg', '2024-05-31', 1584, 1, 0, 1, 'trang', '1 kg', NULL, NULL),
(783, 'Nước hoa nam', 5, 25376917, 10109589, 'product-9.jpg', '2024-05-31', 92, 0, 1, 0, 'trang', '3 kg', NULL, NULL),
(784, 'Bạc', 8, 28611735, 14128831, 'cat-4.jpg', '2024-05-31', 475, 1, 1, 3, 'vang', '1 kg', NULL, NULL),
(785, 'Apple', 8, 28482322, 12434244, 'product-9.jpg', '2024-05-31', 226, 1, 1, 4, 'trang', '2 kg', NULL, NULL),
(786, 'Camera', 8, 20558695, 10584201, 'product-7.jpg', '2024-05-31', 1259, 0, 0, 2, 'trang', '1 kg', NULL, NULL),
(787, 'Kim cương', 3, 27002645, 14715309, 'cat-2.jpg', '2024-05-31', 1603, 0, 1, 0, 'cam', '1 kg', NULL, NULL),
(788, 'Camera', 4, 23628808, 14061829, 'product-5.jpg', '2024-05-31', 1824, 1, 1, 4, 'cam', '3 kg', NULL, NULL),
(789, 'Lenovo', 9, 27645909, 11479359, 'product-7.jpg', '2024-05-31', 853, 1, 1, 4, 'cam', '1 kg', NULL, NULL),
(790, 'Mx97', 2, 24308319, 13381694, 'product-7.jpg', '2024-05-31', 847, 0, 1, 4, 'den', '2 kg', NULL, NULL),
(791, 'Đầm phụ nữ', 10, 24400798, 10602233, 'cat-4.jpg', '2024-05-31', 1757, 1, 1, 0, 'vang', '3 kg', NULL, NULL),
(792, 'Mx97', 1, 26144254, 12952571, 'product-9.jpg', '2024-05-31', 484, 0, 1, 0, 'trang', '2 kg', NULL, NULL),
(793, 'G12', 4, 28680319, 13877170, 'cat-3.jpg', '2024-05-31', 918, 0, 1, 1, 'trang', '1 kg', NULL, NULL),
(794, 'Đầm phụ nữ', 4, 26662035, 11578136, 'product-9.jpg', '2024-05-31', 1146, 1, 0, 4, 'cam', '1 kg', NULL, NULL),
(795, 'Camera', 7, 22775525, 10303440, 'product-3.jpg', '2024-05-31', 852, 1, 1, 3, 'den', '1 kg', NULL, NULL),
(796, 'G12', 6, 26863623, 14147965, 'product-2.jpg', '2024-05-31', 1284, 0, 0, 4, 'den', '1 kg', NULL, NULL),
(797, 'Asus', 3, 26418368, 10807873, 'product-3.jpg', '2024-05-31', 1692, 0, 1, 0, 'den', '1 kg', NULL, NULL),
(798, 'Vàng', 6, 29282885, 13309821, 'product-8.jpg', '2024-05-31', 1443, 1, 1, 3, 'trang', '1 kg', NULL, NULL),
(799, 'Vàng', 10, 22478018, 11631934, 'product-7.jpg', '2024-05-31', 389, 0, 0, 1, 'cam', '3 kg', NULL, NULL),
(800, 'Kim cương', 5, 23571761, 10942512, 'cat-1.jpg', '2024-05-31', 394, 0, 0, 4, 'trang', '3 kg', NULL, NULL),
(801, 'Nước hoa nam', 5, 25745342, 13921415, 'product-8.jpg', '2024-05-31', 1137, 0, 1, 1, 'vang', '3 kg', NULL, NULL),
(802, 'Iphone', 5, 23944060, 12012324, 'cat-3.jpg', '2024-05-31', 410, 0, 1, 2, 'den', '3 kg', NULL, NULL),
(803, 'Iphone', 7, 25735831, 10217046, 'cat-2.jpg', '2024-05-31', 1815, 0, 0, 2, 'den', '3 kg', NULL, NULL),
(804, 'Apple', 2, 29488414, 10795496, 'product-7.jpg', '2024-05-31', 345, 0, 1, 4, 'trang', '1 kg', NULL, NULL),
(805, 'Camera', 10, 26578555, 10545873, 'product-6.jpg', '2024-05-31', 1367, 1, 1, 0, 'vang', '2 kg', NULL, NULL),
(806, 'G12', 7, 28940142, 10321245, 'cat-3.jpg', '2024-05-31', 429, 1, 1, 0, 'trang', '1 kg', NULL, NULL),
(807, 'Bạc', 4, 28419481, 12392466, 'cat-3.jpg', '2024-05-31', 82, 0, 0, 2, 'den', '3 kg', NULL, NULL),
(808, 'Camera', 3, 27634643, 13414241, 'cat-3.jpg', '2024-05-31', 1886, 1, 1, 2, 'vang', '3 kg', NULL, NULL),
(809, 'Asus', 2, 26262325, 14396002, 'product-4.jpg', '2024-05-31', 322, 1, 1, 1, 'vang', '3 kg', NULL, NULL),
(810, 'Asus', 7, 24058093, 12882958, 'product-9.jpg', '2024-05-31', 228, 0, 1, 4, 'den', '2 kg', NULL, NULL),
(811, 'Mx97', 5, 28828200, 10623063, 'cat-3.jpg', '2024-05-31', 993, 0, 0, 4, 'den', '1 kg', NULL, NULL),
(812, 'Nước hoa nữ', 3, 27085603, 12609563, 'product-8.jpg', '2024-05-31', 1110, 1, 1, 3, 'den', '3 kg', NULL, NULL),
(813, 'Nước hoa nam', 5, 21629769, 10777426, 'product-5.jpg', '2024-05-31', 1417, 1, 1, 3, 'den', '2 kg', NULL, NULL),
(814, 'Lenovo', 6, 22992011, 12931255, 'product-6.jpg', '2024-05-31', 1927, 1, 0, 4, 'vang', '1 kg', NULL, NULL),
(815, 'Kim cương', 5, 20242599, 14062267, 'product-8.jpg', '2024-05-31', 251, 1, 1, 4, 'trang', '3 kg', NULL, NULL),
(816, 'Banana', 6, 29624180, 13299377, 'product-2.jpg', '2024-05-31', 1542, 1, 1, 0, 'vang', '2 kg', NULL, NULL),
(817, 'Đầm phụ nữ', 10, 22357834, 13031432, 'product-3.jpg', '2024-05-31', 676, 1, 0, 4, 'cam', '1 kg', NULL, NULL),
(818, 'Nước hoa nữ', 5, 21857151, 10239604, 'cat-4.jpg', '2024-05-31', 1178, 0, 1, 4, 'vang', '1 kg', NULL, NULL),
(819, 'Banana', 9, 29516700, 10778678, 'cat-4.jpg', '2024-05-31', 712, 0, 0, 2, 'vang', '2 kg', NULL, NULL),
(820, 'Đầm phụ nữ', 1, 27234300, 13949690, 'cat-1.jpg', '2024-05-31', 367, 1, 0, 3, 'vang', '1 kg', NULL, NULL),
(821, 'Nước hoa nữ', 2, 25610949, 14555792, 'cat-4.jpg', '2024-05-31', 153, 1, 1, 0, 'trang', '3 kg', NULL, NULL),
(822, 'Lenovo', 8, 25463473, 11139178, 'product-3.jpg', '2024-05-31', 1825, 1, 1, 2, 'trang', '2 kg', NULL, NULL),
(823, 'Iphone', 4, 21218967, 14919447, 'cat-1.jpg', '2024-05-31', 1696, 1, 0, 3, 'cam', '3 kg', NULL, NULL),
(824, 'Apple', 10, 26807291, 10000790, 'product-7.jpg', '2024-05-31', 255, 1, 0, 3, 'vang', '3 kg', NULL, NULL),
(825, 'Kim cương', 1, 24551110, 13145146, 'product-8.jpg', '2024-05-31', 1758, 1, 0, 0, 'den', '2 kg', NULL, NULL),
(826, 'Iphone', 2, 20658613, 14800557, 'cat-2.jpg', '2024-05-31', 133, 1, 0, 4, 'cam', '1 kg', NULL, NULL),
(827, 'G12', 1, 20210178, 14123383, 'cat-1.jpg', '2024-05-31', 1307, 0, 1, 3, 'den', '1 kg', NULL, NULL),
(828, 'Mx97', 1, 24764570, 10308962, 'product-4.jpg', '2024-05-31', 859, 0, 1, 3, 'vang', '2 kg', NULL, NULL),
(829, 'Apple', 5, 26471530, 10762994, 'product-5.jpg', '2024-05-31', 15, 1, 1, 4, 'trang', '1 kg', NULL, NULL),
(830, 'Nước hoa nữ', 6, 22466689, 12457099, 'product-6.jpg', '2024-05-31', 1107, 0, 1, 2, 'cam', '1 kg', NULL, NULL),
(831, 'Asus', 6, 26182353, 13248631, 'cat-1.jpg', '2024-05-31', 851, 0, 1, 0, 'den', '2 kg', NULL, NULL),
(832, 'Banana', 7, 26581092, 12702527, 'product-4.jpg', '2024-05-31', 1244, 1, 0, 3, 'den', '1 kg', NULL, NULL),
(833, 'Đầm phụ nữ', 9, 27817855, 14616209, 'product-8.jpg', '2024-05-31', 1585, 1, 1, 1, 'vang', '1 kg', NULL, NULL),
(834, 'Apple', 4, 22648407, 11283636, 'product-5.jpg', '2024-05-31', 1931, 1, 1, 1, 'cam', '1 kg', NULL, NULL),
(835, 'Bạc', 2, 26070213, 13684259, 'product-4.jpg', '2024-05-31', 1163, 1, 1, 0, 'cam', '1 kg', NULL, NULL),
(836, 'Mx97', 8, 22301398, 12573635, 'product-9.jpg', '2024-05-31', 1854, 0, 0, 3, 'den', '3 kg', NULL, NULL),
(837, 'Nước hoa nữ', 4, 28928576, 14049040, 'cat-2.jpg', '2024-05-31', 407, 0, 0, 0, 'cam', '1 kg', NULL, NULL),
(838, 'Nước hoa nam', 1, 26938098, 12362342, 'product-3.jpg', '2024-05-31', 197, 1, 0, 2, 'den', '1 kg', NULL, NULL),
(839, 'Banana', 8, 25922762, 13263591, 'product-3.jpg', '2024-05-31', 974, 1, 1, 0, 'trang', '1 kg', NULL, NULL),
(840, 'Mx97', 5, 25946549, 14299209, 'cat-2.jpg', '2024-05-31', 816, 1, 0, 1, 'den', '2 kg', NULL, NULL),
(841, 'Apple', 10, 28249299, 14153100, 'product-9.jpg', '2024-05-31', 523, 1, 0, 1, 'den', '1 kg', NULL, NULL),
(842, 'Camera', 10, 24535082, 11532404, 'product-1.jpg', '2024-05-31', 1731, 0, 0, 1, 'den', '3 kg', NULL, NULL),
(843, 'Mx97', 3, 29290951, 10127028, 'product-7.jpg', '2024-05-31', 1043, 0, 1, 2, 'den', '3 kg', NULL, NULL),
(844, 'Bạc', 2, 26533826, 12851404, 'product-5.jpg', '2024-05-31', 164, 0, 0, 1, 'cam', '1 kg', NULL, NULL),
(845, 'Asus', 8, 23254204, 14023069, 'cat-3.jpg', '2024-05-31', 1238, 0, 0, 1, 'cam', '1 kg', NULL, NULL),
(846, 'Vàng', 5, 25938997, 11320253, 'product-5.jpg', '2024-05-31', 270, 1, 0, 3, 'vang', '3 kg', NULL, NULL),
(847, 'Camera', 2, 22850942, 11090589, 'product-4.jpg', '2024-05-31', 166, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(848, 'Kim cương', 4, 28846382, 14753000, 'product-1.jpg', '2024-05-31', 867, 1, 0, 4, 'cam', '2 kg', NULL, NULL),
(849, 'Nước hoa nam', 7, 29611667, 11656969, 'cat-2.jpg', '2024-05-31', 407, 0, 1, 4, 'cam', '1 kg', NULL, NULL),
(850, 'G12', 6, 24721679, 12347030, 'cat-4.jpg', '2024-05-31', 1590, 1, 0, 0, 'cam', '3 kg', NULL, NULL),
(851, 'Đầm phụ nữ', 9, 27392060, 12936048, 'product-8.jpg', '2024-05-31', 436, 0, 0, 4, 'cam', '2 kg', NULL, NULL),
(852, 'Đầm phụ nữ', 6, 20937391, 14935160, 'product-3.jpg', '2024-05-31', 1472, 0, 1, 2, 'trang', '1 kg', NULL, NULL),
(853, 'Nước hoa nam', 4, 20507538, 11970535, 'product-8.jpg', '2024-05-31', 1512, 1, 0, 0, 'den', '1 kg', NULL, NULL),
(854, 'Lenovo', 5, 24095657, 14980594, 'product-3.jpg', '2024-05-31', 1504, 0, 1, 2, 'trang', '2 kg', NULL, NULL),
(855, 'Apple', 6, 28791072, 11087308, 'product-4.jpg', '2024-05-31', 773, 0, 0, 0, 'vang', '2 kg', NULL, NULL),
(856, 'Bạc', 2, 22183119, 12655461, 'product-7.jpg', '2024-05-31', 409, 1, 0, 2, 'cam', '3 kg', NULL, NULL),
(857, 'Đầm phụ nữ', 3, 27306005, 10622162, 'product-3.jpg', '2024-05-31', 603, 0, 1, 1, 'den', '2 kg', NULL, NULL),
(858, 'Iphone', 10, 24388164, 13263048, 'product-7.jpg', '2024-05-31', 485, 0, 1, 2, 'den', '1 kg', NULL, NULL),
(859, 'Mx97', 6, 26777779, 10546143, 'product-8.jpg', '2024-05-31', 1992, 1, 0, 0, 'cam', '2 kg', NULL, NULL),
(860, 'Lenovo', 9, 23848882, 10300678, 'product-4.jpg', '2024-05-31', 1038, 0, 0, 4, 'vang', '2 kg', NULL, NULL),
(861, 'Vàng', 7, 22980389, 12452017, 'cat-4.jpg', '2024-05-31', 1685, 1, 1, 3, 'den', '1 kg', NULL, NULL),
(862, 'Mx97', 5, 20656166, 10070541, 'product-9.jpg', '2024-05-31', 384, 0, 0, 0, 'vang', '2 kg', NULL, NULL),
(863, 'Apple', 7, 27951857, 10554741, 'product-7.jpg', '2024-05-31', 358, 1, 0, 0, 'cam', '3 kg', NULL, NULL),
(864, 'Bạc', 9, 20556018, 12898852, 'product-9.jpg', '2024-05-31', 605, 1, 0, 3, 'den', '3 kg', NULL, NULL),
(865, 'Apple', 5, 26065323, 10329132, 'cat-1.jpg', '2024-05-31', 315, 1, 1, 3, 'vang', '3 kg', NULL, NULL),
(866, 'Asus', 9, 25231530, 12662698, 'cat-4.jpg', '2024-05-31', 343, 1, 0, 0, 'den', '3 kg', NULL, NULL),
(867, 'Banana', 2, 29369764, 11192428, 'cat-2.jpg', '2024-05-31', 1041, 1, 1, 1, 'trang', '2 kg', NULL, NULL),
(868, 'Banana', 3, 26357799, 13005234, 'product-6.jpg', '2024-05-31', 530, 1, 0, 2, 'cam', '1 kg', NULL, NULL),
(869, 'G12', 3, 21495341, 12675521, 'product-7.jpg', '2024-05-31', 786, 1, 1, 0, 'cam', '3 kg', NULL, NULL),
(870, 'Kim cương', 10, 22594698, 14963707, 'product-2.jpg', '2024-05-31', 351, 1, 1, 0, 'vang', '3 kg', NULL, NULL),
(871, 'G12', 3, 25334559, 12383923, 'product-2.jpg', '2024-05-31', 1598, 1, 1, 2, 'cam', '2 kg', NULL, NULL),
(872, 'Mx97', 2, 22092486, 11551594, 'product-9.jpg', '2024-05-31', 103, 0, 0, 2, 'den', '1 kg', NULL, NULL),
(873, 'Apple', 2, 26326608, 14972811, 'product-4.jpg', '2024-05-31', 1990, 1, 1, 4, 'cam', '2 kg', NULL, NULL),
(874, 'Apple', 2, 26202635, 14121061, 'cat-1.jpg', '2024-05-31', 696, 1, 1, 4, 'vang', '3 kg', NULL, NULL),
(875, 'G12', 6, 21859865, 14348087, 'product-4.jpg', '2024-05-31', 721, 0, 1, 0, 'cam', '2 kg', NULL, NULL),
(876, 'Asus', 1, 29109884, 13374937, 'product-2.jpg', '2024-05-31', 1077, 1, 0, 0, 'cam', '1 kg', NULL, NULL),
(877, 'Đầm phụ nữ', 2, 23161323, 12546979, 'product-2.jpg', '2024-05-31', 1508, 0, 1, 0, 'cam', '3 kg', NULL, NULL),
(878, 'Nước hoa nữ', 4, 20513385, 12749178, 'product-8.jpg', '2024-05-31', 1633, 1, 1, 4, 'vang', '3 kg', NULL, NULL),
(879, 'G12', 5, 27535924, 11737790, 'product-2.jpg', '2024-05-31', 1759, 1, 1, 3, 'vang', '1 kg', NULL, NULL),
(880, 'Apple', 7, 27136939, 11031652, 'cat-1.jpg', '2024-05-31', 694, 0, 0, 4, 'vang', '2 kg', NULL, NULL),
(881, 'Apple', 2, 20876392, 12758113, 'product-2.jpg', '2024-05-31', 99, 1, 0, 1, 'vang', '1 kg', NULL, NULL),
(882, 'Kim cương', 3, 25534455, 14614245, 'product-1.jpg', '2024-05-31', 242, 0, 1, 4, 'cam', '3 kg', NULL, NULL),
(883, 'Apple', 6, 23201087, 12634436, 'product-3.jpg', '2024-05-31', 294, 0, 1, 0, 'vang', '3 kg', NULL, NULL),
(884, 'G12', 2, 21776441, 13062569, 'product-8.jpg', '2024-05-31', 1463, 0, 1, 1, 'trang', '1 kg', NULL, NULL),
(885, 'Đầm phụ nữ', 10, 21140645, 11589148, 'cat-2.jpg', '2024-05-31', 926, 0, 0, 1, 'den', '1 kg', NULL, NULL),
(886, 'Apple', 9, 21608769, 13958998, 'cat-3.jpg', '2024-05-31', 1171, 1, 0, 4, 'vang', '1 kg', NULL, NULL),
(887, 'Kim cương', 3, 24272920, 10177829, 'cat-4.jpg', '2024-05-31', 1448, 1, 0, 3, 'den', '1 kg', NULL, NULL),
(888, 'Lenovo', 4, 23586862, 11156197, 'product-5.jpg', '2024-05-31', 497, 0, 1, 4, 'cam', '3 kg', NULL, NULL),
(889, 'Apple', 5, 21835050, 14875544, 'product-2.jpg', '2024-05-31', 1279, 1, 0, 0, 'vang', '3 kg', NULL, NULL),
(890, 'Camera', 7, 29058069, 10425963, 'product-3.jpg', '2024-05-31', 264, 0, 0, 4, 'trang', '2 kg', NULL, NULL),
(891, 'Banana', 5, 21423614, 13962950, 'product-8.jpg', '2024-05-31', 1282, 1, 0, 4, 'cam', '2 kg', NULL, NULL),
(892, 'Asus', 3, 26153824, 11020772, 'product-7.jpg', '2024-05-31', 1542, 1, 1, 1, 'cam', '1 kg', NULL, NULL),
(893, 'Nước hoa nữ', 5, 21787926, 14042812, 'cat-2.jpg', '2024-05-31', 1264, 1, 1, 3, 'vang', '2 kg', NULL, NULL),
(894, 'Camera', 8, 25510750, 12614066, 'product-2.jpg', '2024-05-31', 32, 1, 1, 3, 'trang', '1 kg', NULL, NULL),
(895, 'Lenovo', 8, 27934446, 13913009, 'product-7.jpg', '2024-05-31', 1179, 0, 0, 0, 'den', '1 kg', NULL, NULL),
(896, 'Nước hoa nam', 2, 27249740, 12945295, 'product-6.jpg', '2024-05-31', 875, 0, 1, 4, 'vang', '3 kg', NULL, NULL),
(897, 'Kim cương', 1, 23984144, 11826266, 'product-5.jpg', '2024-05-31', 838, 0, 1, 2, 'vang', '3 kg', NULL, NULL),
(898, 'G12', 3, 25585701, 11297898, 'product-9.jpg', '2024-05-31', 1558, 0, 1, 0, 'den', '2 kg', NULL, NULL),
(899, 'Vàng', 7, 20260778, 13968357, 'cat-2.jpg', '2024-05-31', 1435, 0, 0, 2, 'den', '1 kg', NULL, NULL),
(900, 'Iphone', 8, 24584446, 10892130, 'product-3.jpg', '2024-05-31', 467, 0, 0, 1, 'cam', '3 kg', NULL, NULL),
(901, 'Iphone', 6, 28955024, 12952737, 'product-7.jpg', '2024-05-31', 198, 1, 1, 3, 'den', '3 kg', NULL, NULL),
(902, 'Asus', 8, 20065487, 12907580, 'cat-2.jpg', '2024-05-31', 660, 1, 1, 1, 'den', '3 kg', NULL, NULL),
(903, 'Kim cương', 4, 28308018, 12867351, 'cat-4.jpg', '2024-05-31', 672, 1, 0, 4, 'vang', '3 kg', NULL, NULL),
(904, 'Nước hoa nữ', 4, 28569301, 12578676, 'cat-4.jpg', '2024-05-31', 578, 0, 1, 2, 'den', '1 kg', NULL, NULL),
(905, 'Lenovo', 3, 22087352, 13335461, 'cat-3.jpg', '2024-05-31', 986, 1, 0, 2, 'cam', '2 kg', NULL, NULL),
(906, 'Đầm phụ nữ', 4, 25283509, 10849217, 'product-6.jpg', '2024-05-31', 589, 1, 1, 0, 'cam', '2 kg', NULL, NULL);
INSERT INTO `san_pham` (`id`, `ten`, `idnhasx`, `gia`, `giakm`, `hing`, `ngay`, `xem`, `hot`, `anhien`, `tinhchat`, `mausac`, `cannang`, `created_at`, `updated_at`) VALUES
(907, 'Camera', 10, 21217964, 14330425, 'product-8.jpg', '2024-05-31', 1796, 1, 1, 4, 'den', '3 kg', NULL, NULL),
(908, 'Asus', 1, 26459029, 12459623, 'cat-1.jpg', '2024-05-31', 868, 0, 1, 4, 'cam', '2 kg', NULL, NULL),
(909, 'Camera', 5, 26252594, 14085796, 'product-3.jpg', '2024-05-31', 573, 1, 0, 1, 'trang', '3 kg', NULL, NULL),
(910, 'Banana', 1, 23927358, 12309316, 'product-7.jpg', '2024-05-31', 171, 0, 1, 1, 'den', '2 kg', NULL, NULL),
(911, 'Đầm phụ nữ', 9, 29173503, 10641075, 'cat-3.jpg', '2024-05-31', 144, 0, 0, 4, 'trang', '1 kg', NULL, NULL),
(912, 'Nước hoa nữ', 2, 26506224, 14636606, 'product-8.jpg', '2024-05-31', 1109, 0, 1, 3, 'cam', '2 kg', NULL, NULL),
(913, 'Mx97', 2, 25864196, 11253992, 'cat-1.jpg', '2024-05-31', 1109, 0, 1, 1, 'trang', '2 kg', NULL, NULL),
(914, 'Camera', 10, 24841049, 11643996, 'product-9.jpg', '2024-05-31', 1730, 1, 1, 1, 'vang', '1 kg', NULL, NULL),
(915, 'Bạc', 9, 21699959, 13247087, 'cat-4.jpg', '2024-05-31', 259, 0, 1, 1, 'vang', '2 kg', NULL, NULL),
(916, 'Apple', 10, 25746539, 11358568, 'product-2.jpg', '2024-05-31', 397, 0, 1, 0, 'den', '2 kg', NULL, NULL),
(917, 'G12', 6, 27620656, 12971821, 'product-7.jpg', '2024-05-31', 710, 0, 0, 2, 'vang', '3 kg', NULL, NULL),
(918, 'Lenovo', 7, 22346119, 11101831, 'product-7.jpg', '2024-05-31', 1493, 1, 0, 4, 'den', '2 kg', NULL, NULL),
(919, 'Nước hoa nữ', 1, 29317603, 14391541, 'product-5.jpg', '2024-05-31', 1718, 1, 1, 2, 'trang', '1 kg', NULL, NULL),
(920, 'Đầm phụ nữ', 9, 25501107, 10228854, 'product-3.jpg', '2024-05-31', 1770, 0, 0, 2, 'vang', '3 kg', NULL, NULL),
(921, 'Banana', 1, 21504271, 13257502, 'product-2.jpg', '2024-05-31', 854, 0, 1, 1, 'trang', '3 kg', NULL, NULL),
(922, 'Asus', 9, 20104403, 12132830, 'product-5.jpg', '2024-05-31', 345, 1, 1, 2, 'den', '3 kg', NULL, NULL),
(923, 'Lenovo', 2, 23477985, 12262381, 'cat-1.jpg', '2024-05-31', 1419, 1, 0, 3, 'trang', '1 kg', NULL, NULL),
(924, 'Vàng', 10, 20402991, 13616111, 'cat-4.jpg', '2024-05-31', 996, 1, 0, 0, 'vang', '2 kg', NULL, NULL),
(925, 'Lenovo', 7, 27206531, 11411017, 'product-5.jpg', '2024-05-31', 1914, 1, 1, 4, 'cam', '1 kg', NULL, NULL),
(926, 'Nước hoa nữ', 6, 24804180, 11554618, 'cat-3.jpg', '2024-05-31', 1698, 1, 1, 1, 'vang', '2 kg', NULL, NULL),
(927, 'Asus', 6, 25882285, 14229017, 'cat-3.jpg', '2024-05-31', 192, 1, 1, 2, 'cam', '3 kg', NULL, NULL),
(928, 'Apple', 10, 28677815, 10605158, 'product-9.jpg', '2024-05-31', 1779, 1, 0, 2, 'trang', '1 kg', NULL, NULL),
(929, 'Asus', 1, 27500858, 10911034, 'cat-1.jpg', '2024-05-31', 1153, 0, 1, 3, 'vang', '1 kg', NULL, NULL),
(930, 'Bạc', 3, 29330125, 12885052, 'product-5.jpg', '2024-05-31', 1232, 1, 0, 4, 'trang', '2 kg', NULL, NULL),
(931, 'Banana', 4, 25574735, 11983215, 'product-9.jpg', '2024-05-31', 750, 0, 0, 1, 'vang', '3 kg', NULL, NULL),
(932, 'Banana', 1, 25632257, 13588474, 'product-7.jpg', '2024-05-31', 1192, 0, 0, 2, 'den', '1 kg', NULL, NULL),
(933, 'Apple', 2, 26576729, 10306586, 'product-9.jpg', '2024-05-31', 1072, 1, 0, 4, 'den', '3 kg', NULL, NULL),
(934, 'Bạc', 2, 25247363, 10990535, 'cat-4.jpg', '2024-05-31', 1177, 1, 1, 2, 'cam', '2 kg', NULL, NULL),
(935, 'Apple', 5, 23141881, 13238574, 'product-6.jpg', '2024-05-31', 503, 1, 1, 2, 'den', '3 kg', NULL, NULL),
(936, 'Iphone', 9, 26212753, 14389630, 'product-2.jpg', '2024-05-31', 1475, 0, 1, 4, 'trang', '2 kg', NULL, NULL),
(937, 'Mx97', 9, 24137531, 14478845, 'product-6.jpg', '2024-05-31', 753, 1, 1, 2, 'den', '3 kg', NULL, NULL),
(938, 'Camera', 6, 28155804, 13080933, 'product-7.jpg', '2024-05-31', 353, 0, 0, 0, 'trang', '1 kg', NULL, NULL),
(939, 'Đầm phụ nữ', 7, 25567717, 10307804, 'cat-2.jpg', '2024-05-31', 1230, 1, 0, 4, 'den', '1 kg', NULL, NULL),
(940, 'Mx97', 6, 28912758, 12364260, 'cat-2.jpg', '2024-05-31', 975, 1, 0, 3, 'cam', '1 kg', NULL, NULL),
(941, 'Iphone', 5, 26280663, 10681287, 'product-4.jpg', '2024-05-31', 1085, 1, 0, 0, 'trang', '1 kg', NULL, NULL),
(942, 'Mx97', 6, 26885085, 12332294, 'product-6.jpg', '2024-05-31', 1246, 0, 0, 4, 'cam', '1 kg', NULL, NULL),
(943, 'Nước hoa nữ', 1, 22517460, 10295836, 'product-6.jpg', '2024-05-31', 779, 0, 1, 1, 'den', '2 kg', NULL, NULL),
(944, 'Nước hoa nữ', 4, 24110076, 12637701, 'product-3.jpg', '2024-05-31', 61, 0, 1, 4, 'trang', '2 kg', NULL, NULL),
(945, 'Banana', 10, 22052147, 12480351, 'cat-2.jpg', '2024-05-31', 1793, 0, 1, 0, 'den', '3 kg', NULL, NULL),
(946, 'Camera', 4, 26931074, 12190683, 'product-3.jpg', '2024-05-31', 1496, 0, 1, 0, 'trang', '2 kg', NULL, NULL),
(947, 'Asus', 7, 21362808, 12517070, 'product-4.jpg', '2024-05-31', 490, 1, 0, 2, 'trang', '2 kg', NULL, NULL),
(948, 'G12', 8, 24693662, 14016432, 'product-3.jpg', '2024-05-31', 857, 1, 1, 2, 'vang', '2 kg', NULL, NULL),
(949, 'Lenovo', 7, 23197080, 13297882, 'product-2.jpg', '2024-05-31', 13, 0, 0, 3, 'cam', '1 kg', NULL, NULL),
(950, 'Camera', 6, 21612535, 14846878, 'product-5.jpg', '2024-05-31', 956, 1, 0, 0, 'cam', '2 kg', NULL, NULL),
(951, 'Đầm phụ nữ', 8, 27031826, 11981581, 'product-4.jpg', '2024-05-31', 977, 1, 1, 3, 'den', '1 kg', NULL, NULL),
(952, 'Nước hoa nữ', 8, 25948306, 12999062, 'product-7.jpg', '2024-05-31', 648, 0, 1, 4, 'trang', '2 kg', NULL, NULL),
(953, 'Vàng', 10, 24350778, 13677884, 'product-2.jpg', '2024-05-31', 797, 1, 1, 1, 'trang', '2 kg', NULL, NULL),
(954, 'Đầm phụ nữ', 6, 25098948, 14958507, 'product-9.jpg', '2024-05-31', 507, 1, 1, 3, 'cam', '1 kg', NULL, NULL),
(955, 'Bạc', 1, 22826959, 11555115, 'product-1.jpg', '2024-05-31', 667, 0, 0, 2, 'trang', '2 kg', NULL, NULL),
(956, 'Nước hoa nam', 8, 23981132, 12073250, 'product-8.jpg', '2024-05-31', 308, 1, 0, 3, 'vang', '2 kg', NULL, NULL),
(957, 'G12', 5, 20882800, 12137856, 'product-2.jpg', '2024-05-31', 1322, 1, 1, 4, 'trang', '1 kg', NULL, NULL),
(958, 'Iphone', 3, 26974138, 10417869, 'product-4.jpg', '2024-05-31', 262, 1, 0, 2, 'den', '3 kg', NULL, NULL),
(959, 'Nước hoa nam', 8, 23345608, 13845931, 'product-4.jpg', '2024-05-31', 1799, 0, 0, 0, 'trang', '2 kg', NULL, NULL),
(960, 'Nước hoa nam', 1, 28682803, 13170658, 'product-8.jpg', '2024-05-31', 1889, 0, 0, 1, 'vang', '2 kg', NULL, NULL),
(961, 'Banana', 6, 29688768, 12208595, 'product-9.jpg', '2024-05-31', 802, 0, 0, 3, 'den', '2 kg', NULL, NULL),
(962, 'Asus', 5, 26557144, 12798148, 'product-7.jpg', '2024-05-31', 1229, 1, 1, 4, 'vang', '3 kg', NULL, NULL),
(963, 'Asus', 3, 21732541, 14365419, 'product-2.jpg', '2024-05-31', 230, 0, 1, 3, 'cam', '1 kg', NULL, NULL),
(964, 'G12', 8, 29342606, 13622867, 'product-3.jpg', '2024-05-31', 1950, 0, 0, 0, 'vang', '1 kg', NULL, NULL),
(965, 'Đầm phụ nữ', 7, 24967727, 13277968, 'cat-4.jpg', '2024-05-31', 1948, 0, 1, 4, 'vang', '2 kg', NULL, NULL),
(966, 'Bạc', 9, 26080830, 10762873, 'product-3.jpg', '2024-05-31', 1063, 1, 0, 2, 'cam', '3 kg', NULL, NULL),
(967, 'Lenovo', 6, 22577790, 10158995, 'product-5.jpg', '2024-05-31', 84, 0, 1, 0, 'trang', '1 kg', NULL, NULL),
(968, 'Camera', 9, 21841096, 10570955, 'product-9.jpg', '2024-05-31', 1313, 0, 0, 3, 'den', '1 kg', NULL, NULL),
(969, 'Camera', 6, 23282536, 10554791, 'cat-3.jpg', '2024-05-31', 279, 0, 1, 3, 'cam', '2 kg', NULL, NULL),
(970, 'Nước hoa nam', 5, 21138923, 10972558, 'product-4.jpg', '2024-05-31', 1650, 0, 1, 1, 'cam', '3 kg', NULL, NULL),
(971, 'Đầm phụ nữ', 4, 25593862, 14909888, 'product-7.jpg', '2024-05-31', 860, 0, 1, 1, 'trang', '1 kg', NULL, NULL),
(972, 'Banana', 2, 22216380, 13105334, 'cat-1.jpg', '2024-05-31', 998, 1, 0, 2, 'den', '3 kg', NULL, NULL),
(973, 'G12', 9, 21142145, 13603522, 'product-9.jpg', '2024-05-31', 1729, 0, 1, 3, 'trang', '2 kg', NULL, NULL),
(974, 'Lenovo', 9, 28905272, 11382114, 'product-2.jpg', '2024-05-31', 814, 1, 0, 1, 'vang', '2 kg', NULL, NULL),
(975, 'Nước hoa nam', 8, 24712599, 11963429, 'product-8.jpg', '2024-05-31', 1198, 1, 0, 3, 'vang', '3 kg', NULL, NULL),
(976, 'Apple', 2, 26275058, 10060051, 'cat-1.jpg', '2024-05-31', 710, 1, 1, 3, 'den', '1 kg', NULL, NULL),
(977, 'Vàng', 1, 28251868, 12976743, 'product-6.jpg', '2024-05-31', 546, 0, 1, 0, 'vang', '2 kg', NULL, NULL),
(978, 'Kim cương', 7, 26694289, 14589533, 'product-6.jpg', '2024-05-31', 1531, 0, 1, 4, 'den', '1 kg', NULL, NULL),
(979, 'Mx97', 5, 25283605, 12991912, 'cat-3.jpg', '2024-05-31', 1460, 1, 1, 3, 'cam', '1 kg', NULL, NULL),
(980, 'Kim cương', 9, 25458913, 11241762, 'product-6.jpg', '2024-05-31', 926, 0, 0, 4, 'cam', '3 kg', NULL, NULL),
(981, 'Kim cương', 2, 21307373, 11311298, 'cat-1.jpg', '2024-05-31', 1830, 1, 1, 4, 'den', '1 kg', NULL, NULL),
(982, 'Camera', 7, 20048173, 14850698, 'cat-4.jpg', '2024-05-31', 499, 0, 1, 0, 'vang', '3 kg', NULL, NULL),
(983, 'Bạc', 10, 28522353, 11671919, 'cat-3.jpg', '2024-05-31', 1564, 1, 0, 2, 'vang', '3 kg', NULL, NULL),
(984, 'Nước hoa nam', 6, 26386328, 10128694, 'product-9.jpg', '2024-05-31', 133, 0, 1, 0, 'vang', '3 kg', NULL, NULL),
(985, 'Nước hoa nữ', 7, 29675185, 13508291, 'product-8.jpg', '2024-05-31', 741, 0, 1, 4, 'trang', '2 kg', NULL, NULL),
(986, 'Nước hoa nam', 10, 29279038, 10728491, 'cat-1.jpg', '2024-05-31', 567, 1, 0, 1, 'den', '1 kg', NULL, NULL),
(987, 'Apple', 1, 26128782, 10191395, 'cat-4.jpg', '2024-05-31', 693, 0, 1, 4, 'cam', '3 kg', NULL, NULL),
(988, 'G12', 2, 29352370, 11747121, 'cat-1.jpg', '2024-05-31', 237, 1, 0, 1, 'cam', '3 kg', NULL, NULL),
(989, 'Nước hoa nam', 4, 20250105, 14852563, 'cat-2.jpg', '2024-05-31', 293, 0, 1, 1, 'cam', '2 kg', NULL, NULL),
(990, 'Vàng', 7, 21718642, 12166555, 'product-8.jpg', '2024-05-31', 747, 1, 0, 4, 'vang', '1 kg', NULL, NULL),
(991, 'Bạc', 1, 20021189, 11770790, 'cat-1.jpg', '2024-05-31', 343, 0, 0, 3, 'vang', '1 kg', NULL, NULL),
(992, 'Asus', 3, 20863254, 12043340, 'product-6.jpg', '2024-05-31', 454, 0, 1, 2, 'trang', '3 kg', NULL, NULL),
(993, 'Đầm phụ nữ', 9, 21663145, 10572141, 'cat-3.jpg', '2024-05-31', 1008, 0, 1, 2, 'trang', '2 kg', NULL, NULL),
(994, 'Mx97', 7, 23264882, 10311038, 'product-2.jpg', '2024-05-31', 985, 0, 0, 2, 'cam', '2 kg', NULL, NULL),
(995, 'Iphone', 8, 25005298, 12200207, 'product-1.jpg', '2024-05-31', 1669, 1, 1, 0, 'vang', '1 kg', NULL, NULL),
(996, 'Camera', 9, 23580806, 11519731, 'product-8.jpg', '2024-05-31', 1226, 0, 1, 3, 'trang', '3 kg', NULL, NULL),
(997, 'G12', 4, 29856070, 10505741, 'product-7.jpg', '2024-05-31', 1385, 1, 1, 4, 'vang', '1 kg', NULL, NULL),
(998, 'Đầm phụ nữ', 10, 20723843, 12152160, 'product-2.jpg', '2024-05-31', 310, 0, 0, 1, 'trang', '3 kg', NULL, NULL),
(999, 'Vàng', 2, 26558487, 14220326, 'product-8.jpg', '2024-05-31', 234, 0, 0, 2, 'cam', '2 kg', NULL, NULL),
(1000, 'Mx97', 2, 26100651, 13595053, 'cat-4.jpg', '2024-05-31', 690, 0, 1, 0, 'cam', '2 kg', NULL, NULL),
(1001, 'Máy ảnh', 7, 123456, 12345, 'cat-1.jpg', '2024-06-03', 132, 1, 1, 4, 'hồng', '3', '2024-06-03 00:18:05', '2024-06-03 00:18:05');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('ZPUWF4UCwA6XqZxChxRW7gDQjCXIYZG2pEH9fFNP', 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiTVVJdEFJRFNoRERJeEVaeHhaZEE1OWVHZ1Y0Q0xqV3BCZnhHRjFzSyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6MzoidXJsIjthOjE6e3M6ODoiaW50ZW5kZWQiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9wcm9kdWN0cyI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjM7fQ==', 1717717327);

-- --------------------------------------------------------

--
-- Table structure for table `tinh_chat`
--

CREATE TABLE `tinh_chat` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ten` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tinh_chat`
--

INSERT INTO `tinh_chat` (`id`, `ten`, `created_at`, `updated_at`) VALUES
(1, 'Bình thường', NULL, NULL),
(2, 'Giá rẻ', NULL, NULL),
(3, 'Giá sốc', NULL, NULL),
(4, 'Cao cấp', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `dia_chi` varchar(255) DEFAULT NULL COMMENT 'Địa chỉ',
  `dien_thoai` varchar(255) DEFAULT NULL COMMENT 'Điện thoại',
  `hinh` varchar(255) DEFAULT NULL COMMENT 'Địa chỉ file hình',
  `role` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 là bình thường, 1 là admin',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `dia_chi`, `dien_thoai`, `hinh`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Đỗ Đạt Cao', 'dodatcao@gmail.com', NULL, '$2y$12$lBALG8dBMNjYF/qds03c0edGAJQSyPSeoGSBn15wZLmwe3ZUsr.FW', '', '0918765238', '', 1, NULL, NULL, NULL),
(2, 'Mai Anh Tới', 'maianhtoi@gmail.com', NULL, '$2y$12$0ZFnwSL5NP5tNSjped71jOOc6AsY8r1efcYNUwaCRmaOuX3BOg.oy', '', '098532482', '', 0, NULL, NULL, NULL),
(3, 'Đào Kho Báu', 'daokhobau@gmail.com', NULL, '$2y$12$w8KOXkeyILyMl0OtlM8HSOF8Z.EzE2zSjpQA6ZjxFDjzhnCJM2SR2', '', '097397392', '', 1, NULL, NULL, NULL),
(5, 'Nguyễn Nhật Tân', 'tannnps33351@fpt.edu.vn', NULL, '$2y$12$dGGLAyZ2fxi5PXuchoE5F.MWPA6s80bDuEsHAq5kFcZouK0ep65DW', NULL, NULL, NULL, 1, NULL, '2024-06-02 10:15:49', '2024-06-02 10:15:49'),
(7, 'Nguyễn Nhật Tân', 'nguyennhattan2328@gmail.com', NULL, '$2y$12$NlYSE2kwJQXryCc5wugv/OpXSSKoPKCg2RH.1RfAmV3sQeGVylP8m', NULL, NULL, NULL, 1, NULL, '2024-06-03 00:12:41', '2024-06-03 00:12:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `binh_luan`
--
ALTER TABLE `binh_luan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `doi_tac`
--
ALTER TABLE `doi_tac`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `don_hang_chi_tiet`
--
ALTER TABLE `don_hang_chi_tiet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nha_sx`
--
ALTER TABLE `nha_sx`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `san_pham`
--
ALTER TABLE `san_pham`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `tinh_chat`
--
ALTER TABLE `tinh_chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `binh_luan`
--
ALTER TABLE `binh_luan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `doi_tac`
--
ALTER TABLE `doi_tac`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `don_hang_chi_tiet`
--
ALTER TABLE `don_hang_chi_tiet`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `nha_sx`
--
ALTER TABLE `nha_sx`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `san_pham`
--
ALTER TABLE `san_pham`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1002;

--
-- AUTO_INCREMENT for table `tinh_chat`
--
ALTER TABLE `tinh_chat`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
